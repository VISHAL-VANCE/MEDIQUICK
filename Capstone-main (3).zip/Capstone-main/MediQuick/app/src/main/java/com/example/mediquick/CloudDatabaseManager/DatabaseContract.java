package com.example.mediquick.CloudDatabaseManager;

public class DatabaseContract {
    private static final String PHP_HOST="b52eoahucywici22jxxa-mysql.services.clever-cloud.com";
    private static final String PHP_USERNAME="udztne7l8lgmgrz2";
    private static final String PHP_PASSWORD="iO7JaxCr5yGqdQmjqa8K";
    private static final String PHP_DATABASE="b52eoahucywici22jxxa";

    protected static final String PHP_URL="jdbc:mysql://"+PHP_HOST+"/"+PHP_DATABASE+"?"+"user="+PHP_USERNAME+"&password="+PHP_PASSWORD+"&connectTimeout=0&autoReconnect=true&useConfigs=maxPerformance&&characterEncoding=UTF-8&&characterSetResults=UTF-8";

    public static final String PHONENUMBER="PhoneNumber";
    public static final String AGE="Age";
    public static final String GENDER="Gender";
    public static final String BLOODGROUP="BloodGroup";
    public static final String ADDRESS="Address";
    public static final String USER_ROLE="UserRole";
    public static final String RELATIVECONTACT1="RelativeContact1";
    public static final String RELATIVECONTACT2="RelativeContact2";
    public static final String RELATIVECONTACT3="RelativeContact3";
    public static final String FIRST_AID_TECH_KNOWN="FirstAidTechKnown";
    public static final String LATITUDE="Latitude";
    public static final String LONGITUDE="Longitude";
    public static final String REPORTS="Reports";


}
