package com.example.mediquick.Utils;

import com.example.mediquick.Contract.MediContract;

import java.util.ArrayList;
import java.util.List;

public class ReportManager {
    public static boolean IsSuspecious(String reports){
        if(reports==null||reports.isEmpty()){
            return false;
        }
        String[] r=reports.split(",");
        if(r.length>=MediContract.MAX_REPORT){
            return true;
        }
        else{
            return false;
        }
    }

    public static String AppendReport(String oldReports,String append){
        if(oldReports==null||oldReports.isEmpty()){
            oldReports="";
        }
        else{
            oldReports+=",";
        }
        return (oldReports+append);
    }
    public static boolean isAlreadyReported(String oldReports,String append){
        if(oldReports==null||oldReports.isEmpty()){
            return false;
        }
        if(oldReports.matches(".*[+]"+append+".*")){
            return true;
        }
        else{
            return false;
        }
    }
}
