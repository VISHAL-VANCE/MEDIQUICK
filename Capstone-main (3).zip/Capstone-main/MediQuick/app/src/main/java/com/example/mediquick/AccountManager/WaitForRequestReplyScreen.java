package com.example.mediquick.AccountManager;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

import com.example.mediquick.R;

public class WaitForRequestReplyScreen extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_wait_for_request_reply_screen);
    }
}