package com.example.mediquick.HelpManager;

import android.Manifest;
import android.app.Activity;
import android.content.Context;
import android.content.pm.PackageManager;
import android.os.Build;

import androidx.annotation.RequiresApi;
import androidx.core.content.ContextCompat;

public class PermissionManager {

    @RequiresApi(api = Build.VERSION_CODES.M)
    public static boolean checkAndGetReadExternalFilesPermission(Context context, int requestCode) {

        if (ContextCompat.checkSelfPermission(context, Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED) {
            return true;
        }
        ((Activity) context).requestPermissions(new String[]{Manifest.permission.READ_EXTERNAL_STORAGE}, requestCode);

        return false;
    }


}
