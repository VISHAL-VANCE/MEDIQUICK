package com.example.mediquick.Group;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.content.ContextCompat;

import com.example.mediquick.Contract.MediContract;
import com.example.mediquick.R;

import java.util.ArrayList;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class ChatConversationAdapter extends ArrayAdapter<String> {
    SharedPreferences sharedPreferences= getContext().getSharedPreferences(String.valueOf(R.string.userpreference),getContext().MODE_PRIVATE);
    String USERNAME;
    public ChatConversationAdapter(@NonNull Context context, int resource, ArrayList<String> arrayList) {
        super(context, resource,arrayList);
    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {

        if(convertView==null){
            convertView= LayoutInflater.from(getContext()).inflate(R.layout.chat_adapter_item,parent,false);
        }

        int aaa;

        USERNAME=sharedPreferences.getString(String.valueOf(R.string.username),"NO_NAME");
        LinearLayout linearLayout=convertView.findViewById(R.id.chatlinearlayout);
        LinearLayout holder_linearLayout=convertView.findViewById(R.id.chat_holder);
        TextView name_textView=convertView.findViewById(R.id.name_text_view);
        TextView msg_textView=convertView.findViewById(R.id.msg_text_view);

        String name=ChatManager.chatSenderList.get(position);
        String s= ChatManager.chatList.get(position);
        Integer del=ChatManager.chatDelList.get(position);

        LinearLayout.LayoutParams holder_params=new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
        );

        double d=linearLayout.getWidth()*0.8/4;
        int n=(int)(d);
        name_textView.setVisibility(View.GONE);





        if(del==1){
            if(name.equals(USERNAME)){
                aaa=1;
                linearLayout.setGravity(Gravity.RIGHT);
                holder_linearLayout.setBackgroundResource(R.drawable.right_chat_background_style);
                msg_textView.setTextColor(ContextCompat.getColor(getContext(),R.color.white));
                name_textView.setText(getContext().getString(R.string.you));
                holder_params.setMargins(n,10,10,10);

            }
            else{
                aaa=2;
                linearLayout.setGravity(Gravity.LEFT);
                holder_linearLayout.setBackgroundResource(R.drawable.left_chat_background_style);
                msg_textView.setTextColor(ContextCompat.getColor(getContext(),R.color.black));
                name_textView.setText(name);
                holder_params.setMargins(10,10,n,10);
            }
            msg_textView.setText("\uD83D\uDEAB"+MediContract.deleted_msg+" by "+name);
            msg_textView.setTextSize(20);


        }
        else {
            if(name.equals(USERNAME)){
                aaa=3;
                linearLayout.setGravity(Gravity.RIGHT);
                holder_linearLayout.setBackgroundResource(R.drawable.right_chat_background_style);
                msg_textView.setTextColor(ContextCompat.getColor(getContext(),R.color.white));
                name_textView.setText(getContext().getString(R.string.you));
                holder_params.setMargins(n,10,10,10);

            }
            else{
                aaa=4;
                linearLayout.setGravity(Gravity.LEFT);
                holder_linearLayout.setBackgroundResource(R.drawable.left_chat_background_style);
                msg_textView.setTextColor(ContextCompat.getColor(getContext(),R.color.black));
                name_textView.setText(name);
                name_textView.setGravity(Gravity.CENTER_VERTICAL|Gravity.LEFT);
                holder_params.setMargins(10,10,n,10);

                if(position!=0){
                    if(!name.equals(ChatManager.chatSenderList.get(position-1))){
                        name_textView.setVisibility(View.VISIBLE);
                    }
                }
                else {
                    name_textView.setVisibility(View.VISIBLE);
                }
            }
            msg_textView.setText(s);
            msg_textView.setTextSize(20);


       }
        holder_linearLayout.setLayoutParams(holder_params);


        return convertView;
    }
}
