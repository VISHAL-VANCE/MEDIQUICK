package com.example.mediquick.Group;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.content.Intent;
import android.media.MediaPlayer;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AbsListView;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.example.mediquick.Contract.MediContract;
import com.example.mediquick.MainActivity;
import com.example.mediquick.NotificationManager.DetailedNotifyActivity;
import com.example.mediquick.NotificationManager.NotificationsActivity;
import com.example.mediquick.R;
import com.example.mediquick.Utils.AlarmPlayerManager;
import com.example.mediquick.Utils.NetworkPermissionManager;
import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class ChatActivity extends AppCompatActivity {

    private ListView chat_list;
    private EditText chatbox;
    private Button send_Button;
    private DatabaseReference dbr1;
    private DatabaseReference grpRemoved_dbr;
    private String USERNAME;
    private String PHNO_NUMBER;
    private String chat_text;
    private ChatConversationAdapter arrayAdapter;
    private String databaseTitle="";
    private ChildEventListener listener;
    private ValueEventListener grpExists_listener;


    private Thread backGroundThread;
    private Boolean stillRunning;

    private String grp_name;

    private View.OnScrollChangeListener onScrollListener;
    private ImageView scroll_imageView;

    private Menu global_menu;

    private int noOfChild=0;
    private int tempnoOfChild=0;
    private Boolean enable_sound=false;
    private static final String TAG= MainActivity.class.getSimpleName();

    @RequiresApi(api = Build.VERSION_CODES.M)
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_chat);



        scroll_imageView=findViewById(R.id.scroll_image);



        ChatManager.chatList=new ArrayList<String>();
        ChatManager.chatSenderList=new ArrayList<String>();
        ChatManager.chatDelList=new ArrayList<Integer>();

        ChatManager.chatList.clear();
        ChatManager.chatSenderList.clear();
        ChatManager.chatDelList.clear();

        grpRemoved_dbr=MediContract.firebaseDatabase.getReference().child(MediContract.GROUPS);

        grp_name=getIntent().getExtras().getString("grp_name");
        USERNAME=getSharedPreferences(String.valueOf(R.string.userpreference),MODE_PRIVATE).getString(String.valueOf(R.string.username),"NO_NAME");
        PHNO_NUMBER=getSharedPreferences(String.valueOf(R.string.userpreference),MODE_PRIVATE).getString(String.valueOf(R.string.contact),"NO_NAME");

        chat_list=(ListView) findViewById(R.id.chat_list);
        arrayAdapter=new ChatConversationAdapter(this,0,ChatManager.chatList);
        chat_list.setAdapter(arrayAdapter);
        chat_list.setSelection(arrayAdapter.getCount()-1);
        chat_list.setOnScrollListener(new AbsListView.OnScrollListener() {

            @Override
            public void onScrollStateChanged(AbsListView view, int scrollState) {
                if (scrollState == AbsListView.OnScrollListener.SCROLL_STATE_IDLE && (chat_list.getLastVisiblePosition() - chat_list.getHeaderViewsCount() -
                        chat_list.getFooterViewsCount()) >= (arrayAdapter.getCount() - 1)) {
                    scroll_imageView.setVisibility(View.INVISIBLE);
                }
                else{
                    scroll_imageView.setVisibility(View.VISIBLE);
                }
            }

            @Override
            public void onScroll(AbsListView view, int firstVisibleItem, int visibleItemCount, int totalItemCount) {

            }
        });

        chatbox=(EditText) findViewById(R.id.chat_box);
        chatbox.setFocusableInTouchMode(true);
        chatbox.requestFocus();

        send_Button=(Button) findViewById(R.id.send_button);

        dbr1= MediContract.firebaseDatabase.getReference().child(MediContract.GROUPS).child(grp_name).child(MediContract.CHATS);
        dbr1.keepSynced(true);


        send_Button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (!NetworkPermissionManager.checkInternetConnection(ChatActivity.this)) {
                    Toast.makeText(ChatActivity.this, getString(R.string.check_internet_connection), Toast.LENGTH_SHORT).show();
                    return;
                }
                chat_text=chatbox.getText().toString().trim();
                if(chat_text.equals("")){
                    return;
                }
                scroll_imageView.setVisibility(View.INVISIBLE);

                String user_msg_key=dbr1.push().getKey();
                DatabaseReference dbr2=dbr1.child(user_msg_key);


                Map<String, Object> map = new HashMap<String, Object>();
                map.put("msg", chat_text);
                map.put("name", USERNAME);
                map.put("zdel","0");
                dbr2.updateChildren(map);
                chatbox.setText("");

                chatbox.setFocusableInTouchMode(true);
                chatbox.requestFocus();

            }
        });

        scroll_imageView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                scrollListDown();
            }
        });
        chat_list.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                if(ChatManager.chatDelList.get(i)==1||!ChatManager.chatSenderList.get(i).equals(USERNAME)){
                    return;
                }
                if(!checkMenuVisibility()){
                    return;
                }

                LinearLayout linearLayout=view.findViewById(R.id.chatlinearlayout);
                if(ChatManager.DELETED_INDEX_ARRAY.contains(i)){
                    linearLayout.setBackgroundColor(getColor(R.color.transparent));
                    ChatManager.DELETED_INDEX_ARRAY.remove(ChatManager.DELETED_INDEX_ARRAY.indexOf(i));
                    if( ChatManager.DELETED_INDEX_ARRAY.size()==0){
                        setMenuVisibility(false);
                    }
                }
                else{
                    linearLayout.setBackgroundColor(getColor(R.color.transparent_light_red));
                    ChatManager.DELETED_INDEX_ARRAY.add(i);

                }
                return;
            }
        });

        chat_list.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(AdapterView<?> adapterView, View view, int i, long l) {
                if(ChatManager.chatDelList.get(i)==1||!ChatManager.chatSenderList.get(i).equals(USERNAME)){
                    return true;
                }

                LinearLayout linearLayout=view.findViewById(R.id.chatlinearlayout);
                if(ChatManager.DELETED_INDEX_ARRAY.contains(i)){
                    linearLayout.setBackgroundColor(getColor(R.color.transparent));
                    ChatManager.DELETED_INDEX_ARRAY.remove(ChatManager.DELETED_INDEX_ARRAY.indexOf(i));
                    if( ChatManager.DELETED_INDEX_ARRAY.size()==0){
                        setMenuVisibility(false);
                    }
                }
                else{
                    linearLayout.setBackgroundColor(getColor(R.color.transparent_light_red));
                    ChatManager.DELETED_INDEX_ARRAY.add(i);
                    if( ChatManager.DELETED_INDEX_ARRAY.size()==1){
                        setMenuVisibility(true);
                    }
                }


                return true;
            }
        });

    }




    private void updateConversation(DataSnapshot dataSnapshot){

        String msg="", user="",del="";
        Iterator i = dataSnapshot.getChildren().iterator();

        int k=0;
        while(i.hasNext()){
            msg = (String) ((DataSnapshot)i.next()).getValue();
            user = (String) ((DataSnapshot)i.next()).getValue();
            del = (String) ((DataSnapshot)i.next()).getValue().toString();
            k++;
        }
        if(!user.equals(USERNAME)){
            scroll_imageView.setVisibility(View.VISIBLE);
        }

        ChatManager.chatSenderList.add(user);
        if(del.equals("0")){
            ChatManager.chatDelList.add(0);
        }
        else {
            ChatManager.chatDelList.add(1);
        }

        if(enable_sound){
            try {
                Thread.sleep(100);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }




        ChatManager.chatList.add(msg);
        arrayAdapter.notifyDataSetChanged();
        if(user.equals(USERNAME)&&del.equals("0")){
            scrollListDown();

        }

        if(enable_sound&&del.equals("0")){


            if(user.equals(USERNAME)){
                AlarmPlayerManager.giveMyChatBeep(ChatActivity.this);
            }
            else {
                AlarmPlayerManager.giveHisChatBeep(ChatActivity.this);
            }
        }

    }

    private void updateDelConversation(DataSnapshot snapshot){
        String msg_key=snapshot.getKey();
        dbr1.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot2) {
                Iterator iterator=snapshot2.getChildren().iterator();
                int position=0;
                while (iterator.hasNext()){

                    String key = (String) ((DataSnapshot)iterator.next()).getKey();
                    if(msg_key.equals(key)){
                        Iterator i = snapshot.getChildren().iterator();
                        while(i.hasNext()){
                            i.next();
                            ChatManager.chatDelList.remove(position);
                            ChatManager.chatDelList.add(position,1);
                            arrayAdapter.notifyDataSetChanged();
                            return;
                        }
                    }
                    position++;

                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });



    }

    private void DeleteMsg(int position){
        dbr1.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                int i=0;
                Iterator iterator=snapshot.getChildren().iterator();
                while (i<position){
                    iterator.next();
                    i++;
                }
                replacemsg(iterator,position);

            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });
    }

    private void replacemsg(Iterator iterator,int position){
        String user_msg_key=(String) ((DataSnapshot)(iterator.next())).getKey();
        Map<String,Object> map=new HashMap<>();
        map.put("zdel","1");
        dbr1.child(user_msg_key).updateChildren(map);

    }
    private void checkWhetherGroupExists(){

        grpExists_listener=grpRemoved_dbr.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                if(!snapshot.hasChild(grp_name)){
                    finish();
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });
    }


    @Override
    protected void onResume() {
        setMenuVisibility(false);

        ChatManager.DELETED_INDEX_ARRAY=new ArrayList<Integer>();
        stillRunning=true;
        backGroundThread=new Thread(new Runnable() {
            @Override
            public void run() {
                if(!stillRunning){
                    return;
                }
                noOfChild=0;
                tempnoOfChild=0;
                enable_sound=false;

                addDatabaseListener();
                checkWhetherGroupExists();
            }
        });

        backGroundThread.start();

        super.onResume();
    }

    @Override
    protected void onPause() {
        dbr1.removeEventListener(listener);
        grpRemoved_dbr.removeEventListener(grpExists_listener);
        stillRunning=false;
        arrayAdapter.clear();
        ChatManager.DELETED_INDEX_ARRAY.clear();
        super.onPause();
    }

    private void addDatabaseListener(){
        dbr1.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                noOfChild=(int)snapshot.getChildrenCount();
                if(noOfChild==0){
                    enable_sound=true;
                }
                addDatabaseListener2();
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });


    }
    private void addDatabaseListener2(){
        listener=dbr1.addChildEventListener(new ChildEventListener() {
            @Override
            public void onChildAdded(@NonNull DataSnapshot snapshot, @Nullable String previousChildName) {

                updateConversation(snapshot);
                tempnoOfChild++;
                if(noOfChild==tempnoOfChild){
                    enable_sound=true;
                }

            }

            @Override
            public void onChildChanged(@NonNull DataSnapshot snapshot, @Nullable String previousChildName) {
                updateDelConversation(snapshot);
            }

            @Override
            public void onChildRemoved(@NonNull DataSnapshot snapshot) {

            }

            @Override
            public void onChildMoved(@NonNull DataSnapshot snapshot, @Nullable String previousChildName) {

            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });
    }
    private void scrollListDown(){
        chat_list.setSelection(arrayAdapter.getCount()-1);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        global_menu=menu;
        getMenuInflater().inflate(R.menu.chat_activity_tab,menu);
        setMenuVisibility(false);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        switch (item.getItemId()){
            case R.id.delete_button:
                deleteBuildAlert();
                break;

            default:
                break;
        }
        return super.onOptionsItemSelected(item);
    }
    private void deleteBuildAlert() {

        final AlertDialog.Builder builder = new AlertDialog.Builder(ChatActivity.this);
        builder.setMessage(getString(R.string.delete_qn))
                .setCancelable(false)
                .setPositiveButton(getString(R.string.delete), new DialogInterface.OnClickListener() {
                    public void onClick(final DialogInterface dialog, final int id) {
                        int position;
                        for(int i=0;i<ChatManager.DELETED_INDEX_ARRAY.size();i++){
                            position=ChatManager.DELETED_INDEX_ARRAY.get(i);
                            String name=ChatManager.chatSenderList.get(position);
                            Integer del=ChatManager.chatDelList.get(position);

                            if(name.equals(USERNAME)&&del==0){
                                DeleteMsg(position);
                            }
                        }
                        LinearLayout linearLayout;
                        for(int i=0;i<ChatManager.DELETED_INDEX_ARRAY.size();i++){
                            linearLayout=getViewByPosition(ChatManager.DELETED_INDEX_ARRAY.get(i)).findViewById(R.id.chatlinearlayout);

                            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                                linearLayout.setBackgroundColor(getColor(R.color.transparent));
                            }

                        }

                        ChatManager.DELETED_INDEX_ARRAY.clear();
                        setMenuVisibility(false);

                    }
                })
                .setNegativeButton(getString(R.string.dont), new DialogInterface.OnClickListener() {
                    public void onClick(final DialogInterface dialog, final int id) {
                        dialog.dismiss();
                    }
                });

        final AlertDialog alert = builder.create();
        alert.show();
    }

    private boolean checkMenuVisibility()
    {
        MenuItem delete_button = global_menu.findItem(R.id.delete_button);
        return delete_button.isVisible();
    }
    private void setMenuVisibility(Boolean b)
    {
        if(global_menu==null){
            return;
        }
        MenuItem delete_button = global_menu.findItem(R.id.delete_button);
        delete_button.setVisible(b);
    }

    public View getViewByPosition(int pos) {
        final int firstListItemPosition =chat_list.getFirstVisiblePosition();
        final int lastListItemPosition = firstListItemPosition + chat_list.getChildCount() - 1;

        if (pos < firstListItemPosition || pos > lastListItemPosition ) {
            return chat_list.getAdapter().getView(pos, null,chat_list);
        } else {
            final int childIndex = pos - firstListItemPosition;
            return chat_list.getChildAt(childIndex);
        }
    }


}