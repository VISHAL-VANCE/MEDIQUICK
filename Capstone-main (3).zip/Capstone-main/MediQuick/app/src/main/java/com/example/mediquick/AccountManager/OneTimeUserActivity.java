package com.example.mediquick.AccountManager;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.example.mediquick.CloudDatabaseManager.DatabaseOperations;
import com.example.mediquick.Contract.MediContract;
import com.example.mediquick.R;
import com.example.mediquick.Utils.NetworkPermissionManager;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.FirebaseException;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.PhoneAuthCredential;
import com.google.firebase.auth.PhoneAuthProvider;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.ValueEventListener;

import java.util.concurrent.TimeUnit;

public class OneTimeUserActivity extends AppCompatActivity {

    private LinearLayout phno_linear_layout;
    private LinearLayout otp_linear_layout;
    private TextView please_wait_view;

    private ProgressBar sendOTPprogressBar;
    private ProgressBar nextprogressBar;

    private EditText phno;
    private EditText otp;

    private TextView haveAccount_button;


    private String prevstarted = "";
    private String phone_number;
    private String verificationCode;

    private Button send_otp;
    private Button next_button;

    private SharedPreferences sharedPreferences;
    private DatabaseReference databaseReference;


    private PhoneAuthProvider.OnVerificationStateChangedCallbacks mCallback;
    private FirebaseAuth auth;

    public static Activity fa;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_one_time_user);

        fa=OneTimeUserActivity.this;

        phno_linear_layout=findViewById(R.id.phno_linear_layout);
        otp_linear_layout=findViewById(R.id.otp_linear_layout);
        please_wait_view=findViewById(R.id.please_wait_view);

        sendOTPprogressBar=findViewById(R.id.send_otp_loading_progress_bar);
        nextprogressBar=findViewById(R.id.next_loading_progress_bar);

        next_button=findViewById(R.id.next_button);

        haveAccount_button=findViewById(R.id.haveAccount_button);
        phno=findViewById(R.id.ph_no);
        phno.setFocusableInTouchMode(true);
        phno.requestFocus();
        otp=findViewById(R.id.otp);

        send_otp=findViewById(R.id.send_otp);

        StartFirebaseLogin();

        sharedPreferences = getSharedPreferences(String.valueOf(R.string.userpreference), MODE_PRIVATE);

        send_otp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showProgressBar(send_otp,sendOTPprogressBar);
                if(!NetworkPermissionManager.checkInternetConnection(OneTimeUserActivity.this)) {
                    Toast.makeText(OneTimeUserActivity.this, getString(R.string.check_internet_connection), Toast.LENGTH_SHORT).show();
                    hideProgressBar(send_otp,sendOTPprogressBar);
                    return;
                }

                if(phno.getText().toString().trim().length()!=10){
                    Toast.makeText(OneTimeUserActivity.this,getString(R.string.invalid_phone_number),Toast.LENGTH_SHORT).show();
                    hideProgressBar(send_otp,sendOTPprogressBar);
                    return;
                }
                phone_number="+91"+phno.getText().toString().trim();
                checkForExistingPhoneNumbers(phone_number);


            }

        });



        next_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showProgressBar(next_button,nextprogressBar);
                if(!NetworkPermissionManager.checkInternetConnection(OneTimeUserActivity.this)) {
                    Toast.makeText(OneTimeUserActivity.this, getString(R.string.check_internet_connection), Toast.LENGTH_SHORT).show();
                    hideProgressBar(next_button,nextprogressBar);
                    return;
                }
                if(otp.getText().toString().trim()==null||otp.getText().toString().trim().length()==0){
                    Toast.makeText(OneTimeUserActivity.this, getString(R.string.please_fill_all_fields), Toast.LENGTH_SHORT).show();
                    hideProgressBar(next_button,nextprogressBar);
                    return;
                }

                String otp_string=otp.getText().toString().trim();
                PhoneAuthCredential credential=PhoneAuthProvider.getCredential(verificationCode,otp_string);
                SignInWith(credential);

            }
        });

        haveAccount_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(OneTimeUserActivity.this,LoginActivty.class);
                startActivity(intent);
            }
        });
    }



    public void StartFirebaseLogin() {
        auth= FirebaseAuth.getInstance();
        //auth.getFirebaseAuthSettings().setAppVerificationDisabledForTesting(true);
        //used to disable Recaptcha

        mCallback=new PhoneAuthProvider.OnVerificationStateChangedCallbacks() {
            @Override
            public void onVerificationCompleted(@NonNull PhoneAuthCredential phoneAuthCredential) {
                Toast.makeText(OneTimeUserActivity.this,getString(R.string.verification_completed),Toast.LENGTH_SHORT).show();
            }

            @Override
            public void onVerificationFailed(@NonNull FirebaseException e) {
                phno_linear_layout.setVisibility(View.VISIBLE);
                otp_linear_layout.setVisibility(View.GONE);
                please_wait_view.setVisibility(View.GONE);
                Log.e("verification_issue", String.valueOf(e));
                Toast.makeText(OneTimeUserActivity.this,getString(R.string.verification_failed),Toast.LENGTH_SHORT).show();
                hideProgressBar(send_otp,sendOTPprogressBar);

            }

            @Override
            public void onCodeSent(@NonNull String s, @NonNull PhoneAuthProvider.ForceResendingToken forceResendingToken) {
                verificationCode=s;

                phno_linear_layout.setVisibility(View.GONE);
                otp_linear_layout.setVisibility(View.VISIBLE);
                please_wait_view.setVisibility(View.GONE);

                otp.setFocusableInTouchMode(true);
                otp.requestFocus();

                Toast.makeText(OneTimeUserActivity.this,getString(R.string.otp_sent),Toast.LENGTH_SHORT).show();
                hideProgressBar(send_otp,sendOTPprogressBar);
                super.onCodeSent(s, forceResendingToken);
            }
        };
    }

    public void SignInWith(PhoneAuthCredential credential){

        auth.signInWithCredential(credential).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
            @Override
            public void onComplete(@NonNull Task<AuthResult> task) {
                if(task.isSuccessful()){

                    NetworkPermissionManager.getPolicyAgreement(OneTimeUserActivity.this,phone_number);

                    hideProgressBar(next_button,nextprogressBar);
                }
                else{
                    Toast.makeText(OneTimeUserActivity.this,getString(R.string.incorrect_otp),Toast.LENGTH_SHORT).show();
                    hideProgressBar(next_button,nextprogressBar);
                }
            }
        });


    }

    public void VerifyPhoneNumber(){
        PhoneAuthProvider.getInstance().verifyPhoneNumber(
                phone_number,
                60,
                TimeUnit.SECONDS,
                OneTimeUserActivity.this,
                mCallback
        );
    }

    public void checkForExistingPhoneNumbers(String ph_no) {



                MediContract.firebaseDatabase.getReference().child("admin").child(ph_no).addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot snapshot) {
                        if(snapshot.exists()){
                            //still the phone number account is waiting for request approval from the admin for first aider

                            Intent intent=new Intent(OneTimeUserActivity.this, WaitForRequestReplyScreen.class);
                            intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP| Intent.FLAG_ACTIVITY_CLEAR_TASK|Intent.FLAG_ACTIVITY_NEW_TASK);
                            startActivity(intent);
                        }
                        else{
                            new Thread(new Runnable() {
                                @Override
                                public void run() {
                                    if(DatabaseOperations.IsNewPhoneNumber(getApplicationContext(),ph_no)){
                                        runOnUiThread(new Runnable() {
                                            @Override
                                            public void run() {
                                                phno_linear_layout.setVisibility(View.GONE);
                                                otp_linear_layout.setVisibility(View.GONE);
                                                please_wait_view.setVisibility(View.VISIBLE);
                                                VerifyPhoneNumber();
                                            }
                                        });
                                    }
                                    else{
                                        MediContract.ShowToast(getApplicationContext(),getString(R.string.phone_already_has_account));
                                        hideProgressBar(send_otp,sendOTPprogressBar);
                                    }
                                }
                            }).start();


                        }
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError error) {

                    }
                });


    }

    private void hideProgressBar(Button button,ProgressBar progressBar){
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                button.setVisibility(View.VISIBLE);
                progressBar.setVisibility(View.GONE);
            }
        });

    }

    private void showProgressBar(Button button,ProgressBar progressBar){
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                button.setVisibility(View.GONE);
                progressBar.setVisibility(View.VISIBLE);
            }
        });

    }

    @Override
    public void onBackPressed() {
        MediContract.onBackPress(OneTimeUserActivity.this);
    }


}