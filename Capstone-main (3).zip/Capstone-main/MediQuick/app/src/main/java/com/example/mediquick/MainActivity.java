package com.example.mediquick;

import android.Manifest;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.location.Location;
import android.location.LocationManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Looper;
import android.telephony.SmsManager;
import android.text.SpannableString;
import android.text.style.UnderlineSpan;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.GridView;
import android.widget.ProgressBar;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import com.example.mediquick.CloudDatabaseManager.DatabaseOperations;
import com.example.mediquick.Contract.MediContract;
import com.example.mediquick.FirstAidTipsManager.FirstAidActivity;
import com.example.mediquick.HelpManager.HelpActivity;
import com.example.mediquick.NotificationManager.NotificationsActivity;
import com.example.mediquick.Utils.ImageUtils;
import com.example.mediquick.Utils.NetworkPermissionManager;
import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationCallback;
import com.google.android.gms.location.LocationRequest;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.location.LocationSettingsRequest;
import com.google.android.gms.location.SettingsClient;
import com.google.firebase.database.DatabaseReference;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.Calendar;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

public class MainActivity extends AppCompatActivity {

    private GridView gridView;
    public static ProbAdapter probAdapter;
    private Button alert_button;
    private ProgressBar progressBar;
    private Intent noti_intent;

    private FusedLocationProviderClient fusedLocationClient;
    private LocationRequest locationRequest;
    private  LocationCallback locationCallback;
    private  LocationCallback initialocationCallback;

    private DatabaseReference databaseReference;
    private SharedPreferences sharedPreferences;

    private String USERNAME;
    private String PHNO_NUMBER;

    private String alert_clicked;

    public static Activity fa;

    private Boolean isbgStarted=false;
    private String problem=null;


    private final String TAG=MainActivity.class.getSimpleName();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        problem=getString(R.string.not_mentioned);
        fa=MainActivity.this;

        noti_intent=new Intent(MainActivity.this, NotificationsActivity.class);

        alert_button = findViewById(R.id.alert_button);
        progressBar=findViewById(R.id.progress_bar);
        gridView=findViewById(R.id.prob_grid_view);
        probAdapter=new ProbAdapter(this,0, ImageUtils.prob_name);
        gridView.setAdapter(probAdapter);
        probAdapter.notifyDataSetChanged();


        sharedPreferences=getSharedPreferences(String.valueOf(R.string.userpreference),MODE_PRIVATE);
        USERNAME=sharedPreferences.getString(String.valueOf(R.string.username),"NO NAME");
        PHNO_NUMBER=sharedPreferences.getString(String.valueOf(R.string.contact),"NO NAME");
        alert_clicked=sharedPreferences.getString(String.valueOf(R.string.alert_clicked),"no");


        databaseReference=MediContract.firebaseDatabase.getReference();

        if(alert_clicked.equals("yes")){
            Intent intent=new Intent(MainActivity.this,AfterAlertActivity.class);
            startActivity(intent);
            finish();
        }


        alert_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(MainActivity.this,getString(R.string.long_press_to_alert),Toast.LENGTH_SHORT).show();
            }
        });

        alert_button.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View v) {
                showProgressBar(alert_button,progressBar);

                if(!NetworkPermissionManager.checkInternetConnection(MainActivity.this)) {
                    Toast.makeText(MainActivity.this, getString(R.string.check_internet_connection), Toast.LENGTH_SHORT).show();
                    hideProgressBar(alert_button,progressBar);
                    return true;
                }
                if (!NetworkPermissionManager.checklocationAccess(MainActivity.this)) {
                    hideProgressBar(alert_button,progressBar);
                    return true;
                }
                problem= probAdapter.getProblem();
                new Thread(new Runnable() {
                    @Override
                    public void run() {
                        if(DatabaseOperations.GetReports(getApplicationContext())){

                            UpdateLocation();
                        }
                    }
                }).start();

                return true;
            }
        });

    }

    public void TriggerUsers(Double lat,Double lon){

        final long time= Calendar.getInstance().getTimeInMillis();
        String t=PHNO_NUMBER+"|"+time+"|"+problem+"|"+lat+"|"+lon;


        Map<String,Object> mapT=new HashMap<>();
        mapT.put("0",t);

        Map<String,Object> map=new HashMap<>();

        try{
            new Thread(new Runnable() {
                @Override
                public void run() {
                    Map<String,Object> rsMap=DatabaseOperations.GetUserLatLong();
                    if(rsMap==null){
                        MediContract.ShowToast(getApplicationContext(),getString(R.string.cannot_locate_others));
                    }
                    else{
                        String phno;
                        Double lat2;
                        Double lon2;
                        ResultSet rs=(ResultSet) rsMap.get("rs");
                        PreparedStatement stmt =(PreparedStatement) rsMap.get("stmt");
                        Connection conn=(Connection) rsMap.get("conn");

                        try{
                            if(rs==null){
                                MediContract.ShowToast(getApplicationContext(),getString(R.string.cannot_locate_others));
                            }
                            else{
                                while(rs.next()){
                                    phno=rs.getString("PhoneNumber");
                                    lat2=rs.getDouble("Latitude");
                                    lon2=rs.getDouble("Longitude");

                                    if(phno==null||phno.equals(PHNO_NUMBER)||lat2==null||lon2==null){
                                        continue;
                                    }


                                    if(CheckForDistance(lat,lon,lat2,lon2)) {
                                        map.clear();
                                        map.put(databaseReference.child(MediContract.USERS).child(phno).child(MediContract.TRIGGER).push().getKey(),mapT);
                                        databaseReference.child(MediContract.USERS).child(phno).child(MediContract.TRIGGER).updateChildren(map);
                                    }

                                }
                            }
                        }catch (Exception e){
                            e.printStackTrace();
                        }
                        finally {
                            DatabaseOperations.DBclose(rs);
                            DatabaseOperations.DBclose(stmt);
                            DatabaseOperations.DBclose(conn);
                        }


                    }
                }
            }).start();

        }catch (Exception e){
            e.printStackTrace();
        }





    }

    public static boolean CheckForDistance(Double lat,Double lon,Double lat2,Double lon2){

//        if(MediContract.distance(lat,lat2,lon,lon2)<=MediContract.DISTANCE_LIMIT*1000) {
//            return true;
//        }
//        else {
//            return false;
//        }

        return true;


    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.main_activity_tab,menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        switch (item.getItemId()){
            case R.id.bell_button:
                startActivity(noti_intent);
                break;
            case R.id.help_button:
                Intent help_intent=new Intent(MainActivity.this, HelpActivity.class);
                startActivity(help_intent);
                break;
            case R.id.first_aid_tips_button:
                Intent first_aid_intent=new Intent(MainActivity.this, FirstAidActivity.class);
                startActivity(first_aid_intent);
                break;
            case R.id.settings_button:
                Intent settings_intent=new Intent(MainActivity.this,SettingsActivity.class);
                startActivity(settings_intent);
                break;
            default:
                break;
        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    public void onBackPressed() {
        MediContract.onBackPress(MainActivity.this);
    }




    private void createGroupChat(){
        MediContract.firebaseDatabase.getReference().child(MediContract.GROUPS).child(PHNO_NUMBER).child(MediContract.CHATS).setValue(0);
    }

    private void setIsAlertedTrue(){
        SharedPreferences.Editor editor=sharedPreferences.edit();
        editor.putBoolean(String.valueOf(R.bool.is_alerted),true);
        editor.apply();
    }

    public void UpdateLocation() {


//        locationCallback = new LocationCallback() {
//            @Override
//            public void onLocationResult(@NonNull LocationResult locationResult) {
//
//                if (locationResult != null) {
//                    for (Location location : locationResult.getLocations()) {
//
//                        if(location==null){
//                            Toast.makeText(MainActivity.this, getString(R.string.problem_with_getting_location), Toast.LENGTH_SHORT).show();
//                            hideProgressBar(alert_button,progressBar);
//                            return;
//                        }
//                        Double lat1 = location.getLatitude();
//                        Double lon1 = location.getLongitude();
//
//                        Log.d(TAG, "Lat:"+lat1+" Lon:"+lon1);
//
//                        databaseReference.child(MediContract.USERS).child(PHNO_NUMBER).child(MediContract.ALERT).setValue("yes");
//                        databaseReference.child(MediContract.USERS).child(PHNO_NUMBER).child(MediContract.ACCEPTED_USERS).setValue(0);
//
//                        TriggerUsers(lat1,lon1);
//                        SharedPreferences.Editor editor=sharedPreferences.edit();
//                        editor.putString(String.valueOf(R.string.alert_clicked),"yes");
//                        editor.putString("problem",probAdapter.getProblem());
//                        editor.apply();
//
//                        ImageUtils.prob_color.clear();
//                        for(int i=0;i<8;i++){
//                            ImageUtils.prob_color.add(i,R.color.white);
//                        }
//                        SpannableString user_name = new SpannableString(USERNAME);
//                        user_name.setSpan(new UnderlineSpan(), 0,user_name.length(), 0);
//
//                        SpannableString problem = new SpannableString(probAdapter.getProblem());
//                        problem.setSpan(new UnderlineSpan(), 0,problem.length(), 0);
//
//                        String gmap_link_uri="https://www.google.com/maps/search/?api=1&query="+lat1+","+lon1;
//                        StringBuffer linkBody=new StringBuffer();
//                        linkBody.append(Uri.parse(gmap_link_uri));
//
//                        String message_String=getString(R.string.your_friend_relative);
//                        message_String+=" "+user_name+" ";
//                        message_String+=getString(R.string.under_emergency);
//                        message_String+=" "+problem+" ";
//                        message_String+=getString(R.string.click_link);
//
//                        Set<String> rset=sharedPreferences.getStringSet(String.valueOf(R.string.rcontact),null);
//                        for (String s : rset){
//                                try {
//                                    SmsManager smsManager = SmsManager.getDefault();
//                                    smsManager.sendTextMessage(s, null,message_String, null, null);
//                                    smsManager.sendTextMessage(s, null,gmap_link_uri, null, null);
//                                } catch (Exception ex) {
//                                    ex.printStackTrace();
//                                }
//
//                        }
//
//                        createGroupChat();
//                        setIsAlertedTrue();
//
//
//                        Intent intent=new Intent(MainActivity.this,AfterAlertActivity.class);
//                        startActivity(intent);
//                        showProgressBar(alert_button,progressBar);
//                        finish();
//
//                    }
//                }
//            }
//
//        };
//
//        startLocationUpdates();

        LocationManager lm = (LocationManager) getSystemService(Context.LOCATION_SERVICE);
        List<String> providers = lm.getProviders(true);

        /* Loop over the array backwards, and if you get an accurate location, then break                 out the loop*/
        Location location = null;

        for (int i = providers.size() - 1; i >= 0; i--) {
            location = lm.getLastKnownLocation(providers.get(i));
            if (location != null) break;
        }

        if (location == null) {
            Toast.makeText(MainActivity.this, getString(R.string.problem_with_getting_location), Toast.LENGTH_SHORT).show();
            hideProgressBar(alert_button, progressBar);
            return;
        }

        Double lat1 = location.getLatitude();
        Double lon1 = location.getLongitude();

        Log.d(TAG, "Lat:" + lat1 + " Lon:" + lon1);

        databaseReference.child(MediContract.USERS).child(PHNO_NUMBER).child(MediContract.ALERT).setValue("yes");
        databaseReference.child(MediContract.USERS).child(PHNO_NUMBER).child(MediContract.ACCEPTED_USERS).setValue(0);

        TriggerUsers(lat1, lon1);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putString(String.valueOf(R.string.alert_clicked), "yes");
        editor.putString("problem", probAdapter.getProblem());
        editor.apply();

        ImageUtils.prob_color.clear();
        for (int i = 0; i < 8; i++) {
            ImageUtils.prob_color.add(i, R.color.white);
        }
        SpannableString user_name = new SpannableString(USERNAME);
        user_name.setSpan(new UnderlineSpan(), 0, user_name.length(), 0);

        SpannableString problem = new SpannableString(probAdapter.getProblem());
        problem.setSpan(new UnderlineSpan(), 0, problem.length(), 0);

        String gmap_link_uri = "https://www.google.com/maps/search/?api=1&query=" + lat1 + "," + lon1;
        StringBuffer linkBody = new StringBuffer();
        linkBody.append(Uri.parse(gmap_link_uri));

        String message_String = getString(R.string.your_friend_relative);
        message_String += " " + user_name + " ";
        message_String += getString(R.string.under_emergency);
        message_String += " " + problem + " ";
        message_String += getString(R.string.click_link);

        Set<String> rset = sharedPreferences.getStringSet(String.valueOf(R.string.rcontact), null);
        for (String s : rset) {
            try {
                SmsManager smsManager = SmsManager.getDefault();
                smsManager.sendTextMessage(s, null, message_String, null, null);
                smsManager.sendTextMessage(s, null, gmap_link_uri, null, null);
            } catch (Exception ex) {
                ex.printStackTrace();
            }

        }

        createGroupChat();
        setIsAlertedTrue();


        Intent intent = new Intent(MainActivity.this, AfterAlertActivity.class);
        startActivity(intent);
        showProgressBar(alert_button, progressBar);
        finish();


    }


    private void startLocationUpdates() {
        final LocationManager manager = (LocationManager) getSystemService(Context.LOCATION_SERVICE);
        if(!manager.isProviderEnabled(LocationManager.GPS_PROVIDER)){
            return;
        }
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            return;
        }



        locationRequest = new LocationRequest();
        locationRequest.setPriority(LocationRequest.PRIORITY_HIGH_ACCURACY);
        locationRequest.setInterval(1000 * 1);
        locationRequest.setFastestInterval(1000 * 1);
        locationRequest.setNumUpdates(1);
        locationRequest.setExpirationDuration(1000*10);

        LocationSettingsRequest.Builder builder = new LocationSettingsRequest.Builder();
        builder.addLocationRequest(locationRequest);
        LocationSettingsRequest locationSettingsRequest = builder.build();

        SettingsClient settingsClient = LocationServices.getSettingsClient(this);
        settingsClient.checkLocationSettings(locationSettingsRequest);
        fusedLocationClient= LocationServices.getFusedLocationProviderClient(this);

        fusedLocationClient.requestLocationUpdates(locationRequest, locationCallback, Looper.getMainLooper());



    }





    @RequiresApi(api = Build.VERSION_CODES.P)
    @Override
    protected void onResume() {
        boolean r;
        boolean t=false;
        boolean s=false;

        r=NetworkPermissionManager.checkLocationPermission(MainActivity.this);
        if(r){
            t=NetworkPermissionManager.checkSMSPermission(MainActivity.this);

        }
        if(r&&t){
            s=NetworkPermissionManager.checklocationAccess(MainActivity.this);
        }

        if(r&&s){
            if(!sharedPreferences.getBoolean(String.valueOf(R.string.isAutoStartAsked),false)){
                sharedPreferences=getSharedPreferences(String.valueOf(R.string.userpreference),MODE_PRIVATE);
                SharedPreferences.Editor editor=sharedPreferences.edit();
                editor.putBoolean(String.valueOf(R.string.isAutoStartAsked),true);
                editor.apply();
                NetworkPermissionManager.checkAutoStart(MainActivity.this);
            }
            if(!isbgStarted){
                MediContract.stopBackgroundService(MainActivity.this);
                MediContract.startBackgroundService(MainActivity.this);
                isbgStarted=true;
            }

        }

        super.onResume();
    }

    private void hideProgressBar(Button button,ProgressBar progressBar){
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                button.setVisibility(View.VISIBLE);
                progressBar.setVisibility(View.GONE);
            }
        });

    }

    private void showProgressBar(Button button,ProgressBar progressBar){
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                button.setVisibility(View.GONE);
                progressBar.setVisibility(View.VISIBLE);
            }
        });

    }


}