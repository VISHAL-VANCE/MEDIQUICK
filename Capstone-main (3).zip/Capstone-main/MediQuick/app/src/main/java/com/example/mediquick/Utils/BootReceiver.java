package com.example.mediquick.Utils;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.location.LocationManager;
import android.util.Log;

import com.example.mediquick.Contract.MediContract;
import com.example.mediquick.MainActivity;
import com.example.mediquick.R;

public class BootReceiver extends BroadcastReceiver {
    private String prev_started = "";
    @Override
    public void onReceive(Context context, Intent intent) {

        if(context.getSharedPreferences(String.valueOf(R.string.userpreference),context.MODE_PRIVATE).getBoolean(prev_started,false)){
            Log.d("BootReceiver", "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX BootReceiver onReceive called");
            MediContract.startBackgroundService(context);
        }
        else{
            Log.d("BootReceiver", "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX MediQuick account doesn't exist");
        }


    }
}
