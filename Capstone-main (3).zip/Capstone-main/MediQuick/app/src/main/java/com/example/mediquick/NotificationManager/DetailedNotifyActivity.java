package com.example.mediquick.NotificationManager;

import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.app.NotificationManager;
import android.content.ContentValues;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.example.mediquick.CloudDatabaseManager.DatabaseOperations;
import com.example.mediquick.Contract.MediContract;
import com.example.mediquick.Group.ChatActivity;
import com.example.mediquick.R;
import com.example.mediquick.Utils.AlarmPlayerManager;
import com.example.mediquick.Utils.NetworkPermissionManager;
import com.example.mediquick.Utils.ResponseManager;
import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationServices;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.ValueEventListener;

public class DetailedNotifyActivity extends AppCompatActivity {

    private static final String TAG = DetailedNotifyActivity.class.getSimpleName();
    private TextView name;
    private TextView time;
    private TextView date;
    //private  TextView address;
    private TextView age;
    private  TextView bloodgroup;
    private TextView contact;
   // private TextView rcontact;
    private TextView gender;
    private TextView user_type;
    private TextView problem;
    private TextView distance;
    private String table_id;


    private  String latitude;
    private String longitude;

    //private double lat2, lon2;

    private  FusedLocationProviderClient fusedLocationClient;

    private Button report_button;
    private  Button response_button;
    private Button chat_Button;
    private  TextView alert_state;
    private  Button show_location_button;
    private  ContentValues contentValues;
    private  SharedPreferences sharedPreferences;

    private  String USERNAME;
    private  String PHNO_NUMBER;

    private  DatabaseReference databaseReference;
    private  ValueEventListener valueEventListener;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detailed_notify);

        sharedPreferences = getSharedPreferences(String.valueOf(R.string.userpreference), MODE_PRIVATE);
        USERNAME = sharedPreferences.getString(String.valueOf(R.string.username), "NO NAME");
        PHNO_NUMBER = sharedPreferences.getString(String.valueOf(R.string.contact), "NO NAME");

        fusedLocationClient = LocationServices.getFusedLocationProviderClient(this);

        table_id = getIntent().getStringExtra("table_id");
        int alarm = getIntent().getIntExtra("alarm", 0);

        if (alarm == 1) {
            NotificationManager notifyManager = (NotificationManager) this.getSystemService(Context.NOTIFICATION_SERVICE);
            notifyManager.cancelAll();
            AlarmPlayerManager.StopMediaPlayer();
        }

        name = findViewById(R.id.name);
        time = findViewById(R.id.time);
        date = findViewById(R.id.date);
        //address = findViewById(R.id.address);
        age = findViewById(R.id.age);
        bloodgroup = findViewById(R.id.bloodgroup);
        contact = findViewById(R.id.contact);
       // rcontact = findViewById(R.id.rcontact);
        gender = findViewById(R.id.gender);
        user_type = findViewById(R.id.usertype);
        problem = findViewById(R.id.problem);
        show_location_button = findViewById(R.id.show_location);

        report_button= findViewById(R.id.report_button);


        response_button = findViewById(R.id.response_button);
        alert_state=findViewById(R.id.alert_cancelled_view);

        UpdateUI();

        Cursor cursor = getContentResolver().query(MediContract.FINAL_URI, new String[]{MediContract.RESPONSE, MediContract.ALERT_LIFE}, MediContract.TABLE_ID + "=?", new String[]{table_id}, null);
        if (cursor != null && cursor.moveToFirst()) {
            @SuppressLint("Range") String res = cursor.getString(cursor.getColumnIndex(MediContract.RESPONSE));
            if (res == null || res.equals("")||res.isEmpty() || res.equals(MediContract.REJECTED)) {
                response_button.setText(getString(R.string.accept));
            } else {
                response_button.setText(getString(R.string.reject));
            }
        }

        contentValues = new ContentValues();
        report_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                new AlertDialog.Builder(DetailedNotifyActivity.this)
                        .setTitle(getResources().getString(R.string.report))
                        .setMessage(getString(R.string.do_you_want_to_report_this_user))
                        .setCancelable(false)
                        .setPositiveButton(getResources().getString(R.string.yes), new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialogInterface, int i) {
                                new Thread(new Runnable() {
                                    @Override
                                    public void run() {
                                        DatabaseOperations.ReportAccount(getApplicationContext(),contact.getText().toString().trim());
                                    }
                                }).start();
                            }
                        })
                        .setNegativeButton(getResources().getString(R.string.no), new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialogInterface, int i) {
                                dialogInterface.dismiss();
                            }
                        })
                        .create()
                        .show();
            }
        });

        response_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (!NetworkPermissionManager.checkInternetConnection(DetailedNotifyActivity.this)) {
                    Toast.makeText(DetailedNotifyActivity.this, getString(R.string.check_internet_connection), Toast.LENGTH_SHORT).show();
                    return;
                }
                if (response_button.getText().equals(getString(R.string.accept))) {
                    response_button.setText(R.string.reject);
                    ResponseManager.InformMyAcceptance(USERNAME,contact.getText().toString().trim());
                    contentValues.put(MediContract.RESPONSE, MediContract.ACCEPTED);

                } else {
                    response_button.setText(getString(R.string.accept));
                    contentValues.put(MediContract.RESPONSE, MediContract.REJECTED);
                    ResponseManager.InformMyRejectance(USERNAME,contact.getText().toString().trim());
                }
                getContentResolver().update(MediContract.FINAL_URI, contentValues, MediContract.TABLE_ID + "=?", new String[]{table_id});


                return;


            }
        });

        chat_Button=findViewById(R.id.chats_button);
        chat_Button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (!NetworkPermissionManager.checkInternetConnection(DetailedNotifyActivity.this)) {
                    Toast.makeText(DetailedNotifyActivity.this, getString(R.string.check_internet_connection), Toast.LENGTH_SHORT).show();
                    return;
                }
                Intent intent=new Intent(DetailedNotifyActivity.this, ChatActivity.class);
                intent.putExtra("grp_name",contact.getText());
                startActivity(intent);
            }
        });

        databaseReference = MediContract.firebaseDatabase.getReference().child(MediContract.USERS).child(contact.getText().toString()).child(MediContract.ALERT);

        if (cursor != null && cursor.getCount()>0&& cursor.moveToFirst()) {
            @SuppressLint("Range") String life = cursor.getString(cursor.getColumnIndex(MediContract.ALERT_LIFE));
            if (life.equals("yes")) {
                response_button.setVisibility(View.VISIBLE);
                chat_Button.setVisibility(View.VISIBLE);
                alert_state.setVisibility(View.GONE);


                setUpAcceptedCount();

                IsAlertLive();
            } else {
                response_button.setVisibility(View.GONE);
                chat_Button.setVisibility(View.GONE);
                alert_state.setVisibility(View.VISIBLE);

                ((TextView) findViewById(R.id.accepted_users_count_text_view)).setVisibility(View.GONE);
            }
        }

        show_location_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (!NetworkPermissionManager.checkInternetConnection(DetailedNotifyActivity.this)) {
                    Toast.makeText(DetailedNotifyActivity.this,  getString(R.string.check_internet_connection), Toast.LENGTH_SHORT).show();
                    return;
                }
                if (!NetworkPermissionManager.checklocationAccess(DetailedNotifyActivity.this)) {
                    return;
                }


                showMap();

            }
        });

    }

    private void setUpAcceptedCount(){

        MediContract.firebaseDatabase.getReference().child(MediContract.USERS).child(contact.getText().toString()).child("accepted_users").addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {


                ((TextView) findViewById(R.id.accepted_users_count_text_view)).setVisibility(View.GONE);

                if(snapshot.exists()){
                    long count = (Long) snapshot.getValue();
                    if(count >= 3){
                        ((TextView) findViewById(R.id.accepted_users_count_text_view)).setVisibility(View.VISIBLE);
                    }
                }

            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });




    }




    @SuppressLint("Range")
    public void UpdateUI() {
        Cursor cursor = getContentResolver().query(MediContract.FINAL_URI, null, MediContract.TABLE_ID + "=?", new String[]{table_id}, null);

        if (cursor != null && cursor.getCount() > 0 && cursor.moveToFirst()) {

            name.setText(cursor.getString(cursor.getColumnIndex(MediContract.NAME)));
            time.setText(cursor.getString(cursor.getColumnIndex(MediContract.TIME)));
            date.setText(cursor.getString(cursor.getColumnIndex(MediContract.DATE)));
            //address.setText(cursor.getString(cursor.getColumnIndex(MediContract.ADDRESS)));
            age.setText(cursor.getString(cursor.getColumnIndex(MediContract.AGE)));
            gender.setText(cursor.getString(cursor.getColumnIndex(MediContract.GENDER)));
            bloodgroup.setText(cursor.getString(cursor.getColumnIndex(MediContract.BLOODGROUP)));
            contact.setText(cursor.getString(cursor.getColumnIndex(MediContract.CONTACT)));
           // rcontact.setText(cursor.getString(cursor.getColumnIndex(MediContract.RCONTACT)));
            user_type.setText(cursor.getString(cursor.getColumnIndex(MediContract.USER_TYPE)));
            problem.setText(cursor.getString(cursor.getColumnIndex(MediContract.PROBLEM)));
            latitude = cursor.getString(cursor.getColumnIndex(MediContract.LATITUDE));
            longitude = cursor.getString(cursor.getColumnIndex(MediContract.LONGITUDE));
        }
        cursor.close();
    }

    public void IsAlertLive() {

        valueEventListener = databaseReference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                try{
                    String v = snapshot.getValue().toString();
                    if (!v.equals("yes")) {
                        contentValues.put(MediContract.ALERT_LIFE, "no");
                        getContentResolver().update(MediContract.FINAL_URI, contentValues, MediContract.TABLE_ID + "=?", new String[]{table_id});
                        response_button.setVisibility(View.GONE);
                        chat_Button.setVisibility(View.GONE);
                        alert_state.setVisibility(View.VISIBLE);

                        databaseReference.removeEventListener(valueEventListener);
                    }
                } catch (Exception e) {
                    finish();
                    Toast.makeText(DetailedNotifyActivity.this,getString(R.string.this_account_has_been_deleted),Toast.LENGTH_SHORT).show();
                    e.printStackTrace();

                }

            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });

    }

    public void showMap() {

        String destination = latitude + "," + longitude;

        String geoUri="https://www.google.com/maps/dir/?api=1&destination="+destination;
        Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(geoUri));
        startActivity(intent);


    }

    @Override
    public void onBackPressed() {
        Intent intent = new Intent(DetailedNotifyActivity.this, NotificationsActivity.class);
        startActivity(intent);
        finish();
        super.onBackPressed();
    }

    @Override
    protected void onResume() {
        NetworkPermissionManager.checkLocationPermission(DetailedNotifyActivity.this);
        super.onResume();
    }


}