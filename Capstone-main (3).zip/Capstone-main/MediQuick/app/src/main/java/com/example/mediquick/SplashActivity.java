package com.example.mediquick;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.Handler;

import androidx.appcompat.app.AppCompatActivity;

import com.example.mediquick.AccountManager.OneTimeUserActivity;
import com.example.mediquick.AdminManager.FirstAiderRequestsActivity;

public class SplashActivity extends AppCompatActivity {
    private String prev_started="";
    private SharedPreferences sharedPreferences;
    private Intent i;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash);

        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                if(getSharedPreferences(String.valueOf(R.string.userpreference),MODE_PRIVATE).getBoolean(prev_started,false)){
                    if(getSharedPreferences(String.valueOf(R.string.userpreference),MODE_PRIVATE).getString(String.valueOf(R.string.usertype), "").equals("Admin")){
                        i=new Intent(SplashActivity.this, FirstAiderRequestsActivity.class);
                    }
                    else{
                        i=new Intent(SplashActivity.this,MainActivity.class);
                    }

                }
                else{
                    i=new Intent(SplashActivity.this, OneTimeUserActivity.class);
                }
                startActivity(i);
                finish();
            }
        },0);



    }



//    public void setLocale(String lang) {
//        Locale myLocale = new Locale(lang);
//        Resources res = getResources();
//        DisplayMetrics dm = res.getDisplayMetrics();
//        Configuration conf = res.getConfiguration();
//        conf.locale = myLocale;
//        res.updateConfiguration(conf, dm);
////        Intent refresh = new Intent(this, AndroidLocalize.class);
////        finish();
////        startActivity(refresh);
//    }

}