package com.example.mediquick.Utils;

import android.content.ContentValues;
import android.content.Context;
import android.util.Log;
import androidx.annotation.NonNull;

import com.example.mediquick.BackgroundTasks.LocationUpdate;
import com.example.mediquick.CloudDatabaseManager.DatabaseOperations;
import com.example.mediquick.Contract.MediContract;
import com.example.mediquick.R;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.ValueEventListener;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.Iterator;
import java.util.Map;

public class AlertInputManager{
    private String name;
    private String time;
    private String date;
    private String address;
    private String age;
    private String bloodgroup;
    private String contact;
    private String gender;
    private String rcontact;
    private String user_type;
    private String problem;
    private String lat;
    private String lon;

    private Context context;

    private static final String TAG=AlertInputManager.class.getSimpleName();


    public AlertInputManager(Context c) {
        context=c;
    }

    private String global_time;

    public void parseInputAlert(String input){
        int len=input.length();
        String temp="";
        int n=0;
        for(int i=0;i<len;i++){

            if(input.charAt(i)=='|'){
                n++;
                switch(n){
                    case 1:
                        contact=temp;
                        break;
                    case 2:
                        time=temp;
                        global_time=time;
                        break;
                    case 3:
                        problem=temp;
                        break;
                    case 4:
                        lat=temp;
                        break;
                    default:
                        break;
                }
                temp="";
            }
            else{
                temp+=input.charAt(i);
                if(i==len-1){
                    lon=temp;
                    temp="";
                }
            }

        }



        try {
            getDetails(contact);
        } catch (Exception e) {
            Log.d(TAG,"XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX Problem with collecting user data");
            e.printStackTrace();
        }

    }

    public void getDetails(String contact){

        new Thread(new Runnable() {
            @Override
            public void run() {
                PreparedStatement stmt=null;
                ResultSet rs=null;
                Connection conn=null;

                Map<String,Object> rsMap=DatabaseOperations.GetUserDetails(contact);
                if(rsMap==null){
                    Log.d(TAG,"Cannot get user details");
                }
                else{
                   rs=(ResultSet) rsMap.get("rs");
                    stmt =(PreparedStatement) rsMap.get("stmt");
                    conn=(Connection) rsMap.get("conn");

                    try{
                        if(rs==null){
                            Log.d(TAG,"Cannot get user details");
                        }
                        else{
                            if(rs.next()){
                                name=rs.getString("UserName");
                                address=rs.getString("Address");
                                age=rs.getString("Age");
                                bloodgroup=rs.getString("BloodGroup");
                                gender=rs.getString("Gender");
                                user_type=rs.getString("UserRole");

                                String rc1=rs.getString("RelativeContact1");
                                String rc2=rs.getString("RelativeContact2");
                                String rc3=rs.getString("RelativeContact3");

                                rcontact=rc1+(rc2==null||rc2.isEmpty()?"":", "+rc2)+(rc3==null||rc3.isEmpty()?"":", "+rc3);

                                try {
                                    ContentValues contentValues=new ContentValues();
                                    contentValues.put(MediContract.ALERT_LIFE, "no");
                                    context.getContentResolver().update(MediContract.FINAL_URI,contentValues, MediContract.CONTACT+ "=?", new String[]{contact});
                                } catch (Exception e) {
                                    e.printStackTrace();
                                }

                                date=MediContract.getDate(Long.valueOf(time));
                                time=MediContract.getTime(context,Long.valueOf(time));

                                ContentValues contentValues=new ContentValues();

                                contentValues.put(MediContract.NAME,name);
                                contentValues.put(MediContract.TIME,time);
                                contentValues.put(MediContract.DATE,date);
                                contentValues.put(MediContract.ADDRESS,address);
                                contentValues.put(MediContract.AGE,age);
                                contentValues.put(MediContract.BLOODGROUP,bloodgroup);
                                contentValues.put(MediContract.CONTACT,contact);
                                contentValues.put(MediContract.RCONTACT,rcontact);
                                contentValues.put(MediContract.GENDER,gender);
                                contentValues.put(MediContract.USER_TYPE,user_type);
                                contentValues.put(MediContract.ALERT_LIFE,"yes");
                                contentValues.put(MediContract.PROBLEM,problem);
                                contentValues.put(MediContract.LATITUDE,lat);
                                contentValues.put(MediContract.LONGITUDE,lon);


                                try {
                                    context.getContentResolver().insert(MediContract.FINAL_URI,contentValues);
                                    LocationUpdate.StartAlarm(context,global_time);
                                    Log.d(TAG,"XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX"+ " Stored Into the Database");



                                } catch (Exception e) {
                                    Log.d(TAG,"XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX"+ " Error while storing Into the Database");
                                    e.printStackTrace();
                                }
                            }
                        }
                    }catch (Exception e){
                        e.printStackTrace();
                    }
                    finally {
                        DatabaseOperations.DBclose(rs);
                        DatabaseOperations.DBclose(stmt);
                        DatabaseOperations.DBclose(conn);
                    }
                }
            }
        }).start();

    }


}
