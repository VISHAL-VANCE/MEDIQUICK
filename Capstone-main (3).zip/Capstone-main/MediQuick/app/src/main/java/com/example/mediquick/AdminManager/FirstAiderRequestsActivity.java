package com.example.mediquick.AdminManager;

import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.ListView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import com.example.mediquick.AccountManager.OneTimeUserActivity;
import com.example.mediquick.Contract.MediContract;
import com.example.mediquick.R;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;

public class FirstAiderRequestsActivity extends AppCompatActivity {

    private static final String LOG_TAG = FirstAiderRequestsActivity.class.getSimpleName();

    private ListView request_list;
    private RequestAdapter requestAdapter;
    private String prevstarted = "";
    
    private static ArrayList<String[]> requestList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_first_aider_requests);

        requestList = new ArrayList<>();

        request_list=findViewById(R.id.request_list);
        requestAdapter=new RequestAdapter(this,0, requestList);
        request_list.setAdapter(requestAdapter);

        getRequestDetails();

    }

    public void getRequestDetails(){

        MediContract.firebaseDatabase.getReference().child("admin").addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {

                for(DataSnapshot dataSnapshot : snapshot.getChildren()){
                    requestList.add(new String[]{dataSnapshot.getKey(), dataSnapshot.getValue().toString()});
                }

                requestAdapter.notifyDataSetChanged();


            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });


    }
    private void signOut() {

        new AlertDialog.Builder(FirstAiderRequestsActivity.this)
                .setTitle(getString(R.string.do_you_want_to_sign_out))
                .setCancelable(false)
                .setPositiveButton(getString(R.string.yes), new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        signOutCode(false);
                    }
                })
                .setNegativeButton(getString(R.string.no), new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        dialogInterface.dismiss();
                    }
                })
                .create()
                .show();
    }

    private void signOutCode(Boolean d){
        MediContract.iDestroy=true;
        MediContract.stopBackgroundService(FirstAiderRequestsActivity.this);


        SharedPreferences sharedPreferences = getSharedPreferences(String.valueOf(R.string.userpreference), MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putBoolean(prevstarted,false);
        editor.apply();

        String ph_no = sharedPreferences.getString(String.valueOf(R.string.contact), null);

        if(d){
            MediContract.firebaseDatabase.getReference().child(MediContract.USERS).child(ph_no).removeValue();
        }



        Intent profile_intent=new Intent(FirstAiderRequestsActivity.this, OneTimeUserActivity.class);
        profile_intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP| Intent.FLAG_ACTIVITY_CLEAR_TASK|Intent.FLAG_ACTIVITY_NEW_TASK);
        startActivity(profile_intent);

        finish();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.first_aider_requests_acitivity_tab,menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        switch (item.getItemId()){
            case R.id.sign_out_button:
                signOut();
                break;
            default:
                break;
        }
        return super.onOptionsItemSelected(item);
    }







}