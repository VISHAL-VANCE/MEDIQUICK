package com.example.mediquick;

import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Spinner;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import com.example.mediquick.AccountManager.OneTimeUserActivity;
import com.example.mediquick.AccountManager.ProfileEditActivity;
import com.example.mediquick.Contract.MediContract;
import com.example.mediquick.MedicalCertificateManager.UploadMedicalCertificateActivity;
import com.example.mediquick.MedicalCertificateManager.ViewMedicalCertificatesActivity;

import java.util.ArrayList;
import java.util.Locale;

public class SettingsActivity extends AppCompatActivity {

    private ListView settings_listView;
    private ArrayList<String> settings_list=new ArrayList<String>();
    private ArrayAdapter<String> arrayAdapter;

    private String prevstarted = "";

    private SharedPreferences sharedPreferences;
    private String PHNO_NUMBER;
    private String profession;

    private Spinner languageSpinner;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_settings);

//        languageSpinner = findViewById(R.id.language_spinner);

        sharedPreferences = getSharedPreferences(String.valueOf(R.string.userpreference), MODE_PRIVATE);
        PHNO_NUMBER = sharedPreferences.getString(String.valueOf(R.string.contact), "NO NAME");

        settings_list.add(getString(R.string.edit_profile));
        settings_list.add(getString(R.string.sign_out));
        settings_list.add(getString(R.string.manage_medical_certificates));

        profession = sharedPreferences.getString(String.valueOf(R.string.usertype), null);
        if(!profession.equals(getString(R.string.normal_person)) && !profession.equals("சாதாரண நபர்")){
            settings_list.add(getString(R.string.view_medical_certificates));
        }

        settings_listView=findViewById(R.id.settings_list_view);
        arrayAdapter=new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1,settings_list);
        settings_listView.setAdapter(arrayAdapter);

        settings_listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                if(position==0){
                    Intent profile_intent=new Intent(SettingsActivity.this, ProfileEditActivity.class);
                    startActivity(profile_intent);
                }
                if(position==1){
                    signOut();
                }
                if(position==2){
                    Intent intent = new Intent(SettingsActivity.this, UploadMedicalCertificateActivity.class);
                    startActivity(intent);
                }
                if(position==3){
                    Intent intent = new Intent(SettingsActivity.this, ViewMedicalCertificatesActivity.class);
                    startActivity(intent);
                }
            }
        });

//        setUpLanguageSpinner();

    }

    private void signOut() {

        new AlertDialog.Builder(SettingsActivity.this)
                .setTitle(getString(R.string.do_you_want_to_sign_out))
                .setCancelable(false)
                .setPositiveButton(getString(R.string.yes), new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                       signOutCode(false);
                    }
                })
                .setNegativeButton(getString(R.string.no), new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        dialogInterface.dismiss();
                    }
                })
                .create()
                .show();
    }

    private void deleteAccount(){
        new AlertDialog.Builder(SettingsActivity.this)
                .setTitle(getString(R.string.do_you_want_to_delete_your_account))
                .setMessage(getString(R.string.you_cannot_recover))
                .setCancelable(false)
                .setPositiveButton(getString(R.string.yes), new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        signOutCode(true);

                    }
                })
                .setNegativeButton(getString(R.string.no), new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        dialogInterface.dismiss();
                    }
                })
                .create()
                .show();
    }

    private void signOutCode(Boolean d){
        MediContract.iDestroy=true;
        MediContract.stopBackgroundService(SettingsActivity.this);


        SharedPreferences sharedPreferences = getSharedPreferences(String.valueOf(R.string.userpreference), MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putBoolean(prevstarted,false);
        editor.apply();

        if(d){
            MediContract.firebaseDatabase.getReference().child(MediContract.USERS).child(PHNO_NUMBER).removeValue();
        }



        Intent profile_intent=new Intent(SettingsActivity.this, OneTimeUserActivity.class);
        profile_intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP| Intent.FLAG_ACTIVITY_CLEAR_TASK|Intent.FLAG_ACTIVITY_NEW_TASK);
        startActivity(profile_intent);

        finish();
    }

    private boolean initLanguageSpinnerSetup = true;

//    public void setUpLanguageSpinner(){
//
//        ArrayAdapter spinnerAdapter=ArrayAdapter.createFromResource(this,R.array.language_spinner_array,android.R.layout.simple_spinner_item);
//        spinnerAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
//
//        languageSpinner.setAdapter(spinnerAdapter);
//
//        int currentLanguageIndex = sharedPreferences.getInt(getString(R.string.language_preference), 0);
//        languageSpinner.setSelection(currentLanguageIndex);
//
//        languageSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
//            @Override
//            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
//                if(initLanguageSpinnerSetup){
//                    initLanguageSpinnerSetup = false;
//                    return;
//                }
//
//                String selection = (String) parent.getItemAtPosition(position);
//                if(!selection.isEmpty()){
//
//                    SharedPreferences.Editor editor = sharedPreferences.edit();
//                    editor.putInt(getString(R.string.language_preference), position);
//
//                    editor.apply();
//
//                    if(position == 0){
//                        setLocale("en");
//                    }
//                    else{
//                        setLocale("ta");
//                    }
//
//                    //restart app
//                    Intent intent=new Intent(SettingsActivity.this, SplashActivity.class);
//                    intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP| Intent.FLAG_ACTIVITY_CLEAR_TASK|Intent.FLAG_ACTIVITY_NEW_TASK);
//                    startActivity(intent);
//
//                }
//            }
//
//            @Override
//            public void onNothingSelected(AdapterView<?> parent) {
//
//            }
//        });
//
//    }


        public void setLocale(String lang) {
            Locale myLocale = new Locale(lang);
            Resources res = getResources();
            DisplayMetrics dm = res.getDisplayMetrics();
            Configuration conf = res.getConfiguration();
            conf.locale = myLocale;
            res.updateConfiguration(conf, dm);
            Intent refresh = new Intent(this, SettingsActivity.class);
            finish();
            startActivity(refresh);
        }



}