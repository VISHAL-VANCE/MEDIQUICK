package com.example.mediquick.AccountManager;


import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.example.mediquick.AdminManager.FirstAiderRequestsActivity;
import com.example.mediquick.CloudDatabaseManager.DatabaseOperations;
import com.example.mediquick.Contract.MediContract;
import com.example.mediquick.MainActivity;
import com.example.mediquick.R;
import com.example.mediquick.Utils.NetworkPermissionManager;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.FirebaseException;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.PhoneAuthCredential;
import com.google.firebase.auth.PhoneAuthProvider;
import com.google.firebase.database.DatabaseReference;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.TimeUnit;

public class LoginActivty extends AppCompatActivity {

    private LinearLayout phno_linear_layout;
    private LinearLayout otp_linear_layout;
    private TextView please_wait_view;

    private ProgressBar sendOTPprogressBar;
    private ProgressBar nextprogressBar;

    private EditText phno;
    private EditText otp;


    private String prevstarted = "";
    private String phone_number;
    private String verificationCode;

    private Button send_otp;
    private Button next_button;

    private SharedPreferences sharedPreferences;
    private DatabaseReference databaseReference;


    private PhoneAuthProvider.OnVerificationStateChangedCallbacks mCallback;
    private FirebaseAuth auth;


    private String name;
    private String age_String;
    private  String gender;
    private  String bloodgrp;
    private  String address_String;
    private  String profession;
    private Set<String> ad_phno_set;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login_activty);

        phno_linear_layout=findViewById(R.id.phno_linear_layout);
        otp_linear_layout=findViewById(R.id.otp_linear_layout);
        please_wait_view=findViewById(R.id.please_wait_view);

        sendOTPprogressBar=findViewById(R.id.send_otp_loading_progress_bar);
        nextprogressBar=findViewById(R.id.next_loading_progress_bar);

        next_button=findViewById(R.id.next_button);
        phno=findViewById(R.id.ph_no);
        phno.setFocusableInTouchMode(true);
        phno.requestFocus();
        otp=findViewById(R.id.otp);

        send_otp=findViewById(R.id.send_otp);


        databaseReference = MediContract.firebaseDatabase.getReference().child(MediContract.USERS);

        StartFirebaseLogin();

        send_otp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showProgressBar(send_otp,sendOTPprogressBar);
                if(!NetworkPermissionManager.checkInternetConnection(LoginActivty.this)) {
                    Toast.makeText(LoginActivty.this, getString(R.string.check_internet_connection), Toast.LENGTH_SHORT).show();
                    hideProgressBar(send_otp,sendOTPprogressBar);
                    return;
                }

                if(phno.getText().toString().trim().length()!=10){
                    Toast.makeText(LoginActivty.this,R.string.invalid_phone_number,Toast.LENGTH_SHORT).show();
                    hideProgressBar(send_otp,sendOTPprogressBar);
                    return;
                }
                phone_number="+91"+phno.getText().toString().trim();
                checkForExistingPhoneNumbers(phone_number);


            }

        });

        next_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showProgressBar(next_button,nextprogressBar);
                if(!NetworkPermissionManager.checkInternetConnection(LoginActivty.this)) {
                    Toast.makeText(LoginActivty.this,getString(R.string.check_internet_connection), Toast.LENGTH_SHORT).show();
                    hideProgressBar(next_button,nextprogressBar);
                    return;
                }
                if(otp.getText().toString().trim().length()==0){
                    Toast.makeText(LoginActivty.this, getString(R.string.please_fill_all_fields), Toast.LENGTH_SHORT).show();
                    hideProgressBar(next_button,nextprogressBar);
                    return;
                }


                String otp_string=otp.getText().toString().trim();
                PhoneAuthCredential credential=PhoneAuthProvider.getCredential(verificationCode,otp_string);
                SignInWith(credential);


            }
        });

    }

    public void StartFirebaseLogin() {
        auth= FirebaseAuth.getInstance();
        mCallback=new PhoneAuthProvider.OnVerificationStateChangedCallbacks() {
            @Override
            public void onVerificationCompleted(@NonNull PhoneAuthCredential phoneAuthCredential) {
                Toast.makeText(LoginActivty.this,getString(R.string.verification_completed),Toast.LENGTH_SHORT).show();
            }

            @Override
            public void onVerificationFailed(@NonNull FirebaseException e) {
                phno_linear_layout.setVisibility(View.VISIBLE);
                otp_linear_layout.setVisibility(View.GONE);
                please_wait_view.setVisibility(View.GONE);
                Log.e("verification_issue", String.valueOf(e));
                Toast.makeText(LoginActivty.this,getString(R.string.verification_failed),Toast.LENGTH_SHORT).show();
                hideProgressBar(send_otp,sendOTPprogressBar);

            }

            @Override
            public void onCodeSent(@NonNull String s, @NonNull PhoneAuthProvider.ForceResendingToken forceResendingToken) {
                verificationCode=s;

                phno_linear_layout.setVisibility(View.GONE);
                otp_linear_layout.setVisibility(View.VISIBLE);
                please_wait_view.setVisibility(View.GONE);

                otp.setFocusableInTouchMode(true);
                otp.requestFocus();

                Toast.makeText(LoginActivty.this,getString(R.string.otp_sent),Toast.LENGTH_SHORT).show();
                hideProgressBar(send_otp,sendOTPprogressBar);
                super.onCodeSent(s, forceResendingToken);
            }
        };
    }

    public void SignInWith(PhoneAuthCredential credential){

        auth.signInWithCredential(credential).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
            @Override
            public void onComplete(@NonNull Task<AuthResult> task) {
                if(task.isSuccessful()){
                    Intent intent=new Intent(LoginActivty.this, MainActivity.class);
                    fetchDetailsfromDatabase();
                }
                else{
                    Toast.makeText(LoginActivty.this,getString(R.string.incorrect_otp),Toast.LENGTH_SHORT).show();
                    hideProgressBar(next_button,nextprogressBar);
                }
            }
        });


    }

    public void VerifyPhoneNumber(){
        PhoneAuthProvider.getInstance().verifyPhoneNumber(
                phone_number,
                60,
                TimeUnit.SECONDS,
                LoginActivty.this,
                mCallback
        );
    }

    public void checkForExistingPhoneNumbers(String ph_no) {

        new Thread(new Runnable() {
            @Override
            public void run() {
                if(DatabaseOperations.IsNewPhoneNumber(getApplicationContext(),ph_no)){
                    MediContract.ShowToast(getApplicationContext(),getString(R.string.phone_has_no_account));
                    hideProgressBar(send_otp,sendOTPprogressBar);
                }
                else{
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            phno_linear_layout.setVisibility(View.GONE);
                            otp_linear_layout.setVisibility(View.GONE);
                            please_wait_view.setVisibility(View.VISIBLE);
                            VerifyPhoneNumber();
                        }
                    });

                }
            }
        }).start();


    }


    public void setSharedPreference(){

        sharedPreferences=getSharedPreferences(String.valueOf(R.string.userpreference),MODE_PRIVATE);

        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putBoolean(prevstarted, true);
        editor.putString(String.valueOf(R.string.username),name);
        editor.putString(String.valueOf(R.string.age),age_String);
        editor.putString(String.valueOf(R.string.gender),gender);
        editor.putString(String.valueOf(R.string.contact),phone_number);
        editor.putStringSet(String.valueOf(R.string.rcontact),ad_phno_set);
        editor.putString(String.valueOf(R.string.bloodgroup),bloodgrp);
        editor.putString(String.valueOf(R.string.address),address_String);
        editor.putString(String.valueOf(R.string.usertype),profession);
        editor.apply();

        hideProgressBar(next_button,nextprogressBar);
        Intent intent = null;

        if(profession.equals("Admin")){
            intent=new Intent(LoginActivty.this, FirstAiderRequestsActivity.class);
        }
        else{
            intent=new Intent(LoginActivty.this, MainActivity.class);
        }
        startActivity(intent);
        OneTimeUserActivity.fa.finish();
        finish();


    }
    public void fetchDetailsfromDatabase(){

        new Thread(new Runnable() {
            @Override
            public void run() {
                PreparedStatement stmt=null;
                ResultSet rs=null;
                Connection conn=null;

                Map<String,Object> rsMap=DatabaseOperations.GetUserDetails(phone_number);
                if(rsMap==null){
                    MediContract.ShowToast(getApplicationContext(),getString(R.string.cannot_fetch_user_account));
                    hideProgressBar(next_button,nextprogressBar);
                }
                else{
                    rs=(ResultSet) rsMap.get("rs");
                    stmt =(PreparedStatement) rsMap.get("stmt");
                    conn=(Connection) rsMap.get("conn");

                    try{
                        if(rs==null){
                            MediContract.ShowToast(getApplicationContext(),getString(R.string.cannot_fetch_user_account));
                            hideProgressBar(next_button,nextprogressBar);
                        }
                        else{
                            if(rs.next()){
                                name=rs.getString("UserName");
                                address_String=rs.getString("Address");
                                age_String=rs.getString("Age");
                                bloodgrp=rs.getString("UserName");
                                gender=rs.getString("Gender");
                                profession=rs.getString("UserRole");

                                String userVerificationStatus = rs.getString("UserVerificationStatus");

                                if(userVerificationStatus.equals(MediContract.UserVerificationStatus.PENDING.toString())){
                                    Intent intent = new Intent(LoginActivty.this, WaitForRequestReplyScreen.class);
                                    intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_NEW_TASK);
                                    startActivity(intent);
                                    return;
                                }
                                else if(userVerificationStatus.equals(MediContract.UserVerificationStatus.NOT_REQUESTED.toString())){
                                    Intent intent=new Intent(LoginActivty.this,account3.class);
                                    intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP| Intent.FLAG_ACTIVITY_CLEAR_TASK|Intent.FLAG_ACTIVITY_NEW_TASK);
                                    intent.putExtra("phone_number",phone_number);
                                    startActivity(intent);
                                    return;
                                }

                                String rc1=rs.getString("RelativeContact1");
                                String rc2=rs.getString("RelativeContact2");
                                String rc3=rs.getString("RelativeContact3");

                                ad_phno_set=new HashSet<>();
                                ad_phno_set.add(rc1);
                                if(rc2!=null&&!rc2.isEmpty()){
                                    ad_phno_set.add(rc2);
                                }
                                if(rc3!=null&&!rc3.isEmpty()){
                                    ad_phno_set.add(rc3);
                                }
                                setSharedPreference();
                            }
                        }
                    }catch (Exception e){
                        e.printStackTrace();
                    }
                    finally {
                        DatabaseOperations.DBclose(rs);
                        DatabaseOperations.DBclose(stmt);
                        DatabaseOperations.DBclose(conn);
                    }
                }
            }
        }).start();


    }

    private void hideProgressBar(Button button,ProgressBar progressBar){
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                button.setVisibility(View.VISIBLE);
                progressBar.setVisibility(View.GONE);
            }
        });

    }

    private void showProgressBar(Button button,ProgressBar progressBar){
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                button.setVisibility(View.GONE);
                progressBar.setVisibility(View.VISIBLE);
            }
        });

    }

}