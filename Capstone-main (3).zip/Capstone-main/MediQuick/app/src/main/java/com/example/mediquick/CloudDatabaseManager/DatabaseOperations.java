package com.example.mediquick.CloudDatabaseManager;

import android.content.Context;
import android.util.Log;

import com.example.mediquick.Contract.MediContract;
import com.example.mediquick.R;
import com.example.mediquick.Utils.ReportManager;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;

public class DatabaseOperations extends DatabaseContract{
    private final static String LOG_TAG=DatabaseOperations.class.getSimpleName();

//    private static Connection conn=null;

    public static Connection InitiateDatabaseConnection(){
        Connection conn=null;
        try{
            Log.d(LOG_TAG,"Connecting to database");
            Class.forName("com.mysql.jdbc.Driver").newInstance();
            conn = DriverManager.getConnection(PHP_URL);
            Log.d(LOG_TAG,"Connection to database successful");

        } catch (Exception e) {
            e.printStackTrace();
        }

        return conn;

    }
    public static boolean Insert(Context context, String Username, String Phonenumber, int Age, String Gender, String Bloodgroup, String Address, String Role, String Relativecontact1, String Relativecontact2, String Relativecontact3, Double Latitude, Double Longitude, String UserVerificationStatus){
        Connection conn=InitiateDatabaseConnection();

        boolean isSuccess=false;
        try {
            if(conn==null||conn.isClosed()){
                return isSuccess;
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        if(!IsNewPhoneNumber(context,Phonenumber)){
            MediContract.ShowToast(context,context.getString(R.string.phone_already_has_account));
            return isSuccess;
        }
        if(!IsNewUserName(context,Username)){
            MediContract.ShowToast(context,context.getString(R.string.user_name_already_taken));
            return isSuccess;
        }

        PreparedStatement stmt=null;

        ResultSet rs=null;
        String sql=null;

        sql="INSERT INTO Users VALUES (null,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?);";
        try{
            stmt=conn.prepareStatement(sql);
            stmt.setObject(1,Username);
            stmt.setObject(2,Phonenumber);
            stmt.setObject(3,Age);
            stmt.setObject(4,Gender);
            stmt.setObject(5,Bloodgroup);
            stmt.setObject(6,Address);
            stmt.setObject(7,Role);
            stmt.setObject(8, Relativecontact1);
            stmt.setObject(9, Relativecontact2);
            stmt.setObject(10,Relativecontact3);
            stmt.setObject(11,null);
            stmt.setObject(12,Latitude);
            stmt.setObject(13,Longitude);
            stmt.setObject(14,null);
            stmt.setObject(15,UserVerificationStatus);
            stmt.execute();
            isSuccess=true;
        }
        catch (SQLException ex){
            ex.printStackTrace();
        }
        catch (Exception e) {
            e.printStackTrace();
        }
        DBclose(rs);
        DBclose(stmt);
        DBclose(conn);
        return isSuccess;
    }
    public static boolean UpdateLatLong(String PhoneNumber,Double latitude,Double longitude){
        Connection conn=InitiateDatabaseConnection();

        boolean isSuccess=false;
        try {
            if(conn==null||conn.isClosed()){
                return isSuccess;
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        PreparedStatement stmt=null;

        try{
            String sql="UPDATE Users SET Latitude=?,Longitude=? WHERE PhoneNumber=?;";
            stmt=conn.prepareStatement(sql);
            stmt.setObject(1,latitude);
            stmt.setObject(2,longitude);
            stmt.setObject(3,PhoneNumber);
            stmt.execute();

            if(stmt.executeUpdate()==0){

            }
            else{
                isSuccess=true;
            }
        }
        catch (SQLException ex){
            ex.printStackTrace();
        }
        catch (Exception e) {
            e.printStackTrace();
        }
        DBclose(stmt);
        DBclose(conn);
        return isSuccess;
    }
    public static Map<String,Object> GetUserLatLong(){
        Connection conn=InitiateDatabaseConnection();
        Map<String,Object> rsMap=null;

        PreparedStatement stmt=null;
        ResultSet rs=null;
        if(conn==null){
            return rsMap;
        }


        try{
            String sql="SELECT PhoneNumber,Latitude,Longitude FROM Users";
            stmt= conn.prepareStatement(sql);
            rs=stmt.executeQuery();
            if(rs!=null){
                System.out.println("select operation is succesful!!");
                rsMap=new HashMap<>();
                rsMap.put("conn",conn);
                rsMap.put("stmt",stmt);
                rsMap.put("rs",rs);
            }


        }
        catch (SQLException ex){
            ex.printStackTrace();
        }
        catch (Exception e) {
            e.printStackTrace();
        }
        return rsMap;
    }
    public static boolean UpdateAllDetails(Context context,String Username,String Phonenumber,int Age,String Gender,String Bloodgroup,String Address,String Role,String Relativecontact1,String Relativecontact2,String Relativecontact3,boolean resetFirstAidTechKnown){
        Connection conn=InitiateDatabaseConnection();
        PreparedStatement stmt=null;
        boolean isSuccess=false;
        try {
            if(conn==null||conn.isClosed()){
                return isSuccess;
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        if(!Username.equals(context.getSharedPreferences(String.valueOf(R.string.userpreference),Context.MODE_PRIVATE).getString(String.valueOf(R.string.username),null))){
            if((!IsNewUserName(context,Username))){
                return isSuccess;
            }
        }

        try{
            String sql;
            if(resetFirstAidTechKnown){
                sql="UPDATE Users SET UserName=?,Age=?,Gender=?,BloodGroup=?,Address=?,UserRole=?,RelativeContact1=?,RelativeContact2=?,RelativeContact3=?,FirstAidTechKnown=? WHERE Phonenumber=?;";
            }
            else{
                sql="UPDATE Users SET UserName=?,Age=?,Gender=?,BloodGroup=?,Address=?,UserRole=?,RelativeContact1=?,RelativeContact2=?,RelativeContact3=? WHERE Phonenumber=?;";
            }

            stmt=conn.prepareStatement(sql);
            stmt.setObject(1,Username);
            stmt.setObject(2,Age);
            stmt.setObject(3,Gender);
            stmt.setObject(4,Bloodgroup);
            stmt.setObject(5,Address);
            stmt.setObject(6,Role);
            stmt.setObject(7, Relativecontact1);
            stmt.setObject(8, Relativecontact2);
            stmt.setObject(9,Relativecontact3);
            if(resetFirstAidTechKnown){
                stmt.setObject(10,null);
                stmt.setObject(11,Phonenumber);
            }
            else{
                stmt.setObject(10,Phonenumber);
            }

            stmt.execute();

            if(stmt.executeUpdate()==0){

            }
            else{
                isSuccess=true;
            }
        }
        catch (SQLException ex){
            ex.printStackTrace();
        }
        catch (Exception e) {
            e.printStackTrace();
        }
        DBclose(stmt);
        DBclose(conn);
        return isSuccess;
    }
    public static boolean UpdateFirstAid(String phoneNumber,String firstaid){
        Connection conn=InitiateDatabaseConnection();
        boolean isSuccess=false;
        try {
            if(conn==null||conn.isClosed()){
                return isSuccess;
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        PreparedStatement stmt=null;

        try{
            String sql="UPDATE Users SET FirstAidTechKnown=? WHERE PhoneNumber=?;";
            stmt=conn.prepareStatement(sql);
            stmt.setObject(1,firstaid);
            stmt.setObject(2,phoneNumber);
            stmt.execute();
            if(stmt.executeUpdate()!=0){
                isSuccess=true;
            }
        }
        catch (SQLException ex){
            ex.printStackTrace();
        }
        catch (Exception e) {
            e.printStackTrace();
        }
        DBclose(stmt);
        DBclose(conn);
        return isSuccess;
    }

    public static boolean UpdateUserVerificationStatus(String phoneNumber,String userVerificationStatus){
        Connection conn=InitiateDatabaseConnection();
        boolean isSuccess=false;
        try {
            if(conn==null||conn.isClosed()){
                return isSuccess;
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        PreparedStatement stmt=null;

        try{
            String sql="UPDATE Users SET UserVerificationStatus=? WHERE PhoneNumber=?;";
            stmt=conn.prepareStatement(sql);
            stmt.setObject(1,userVerificationStatus);
            stmt.setObject(2,phoneNumber);
            stmt.execute();
            if(stmt.executeUpdate()!=0){
                isSuccess=true;
            }
        }
        catch (SQLException ex){
            ex.printStackTrace();
        }
        catch (Exception e) {
            e.printStackTrace();
        }
        DBclose(stmt);
        DBclose(conn);
        return isSuccess;
    }
    public static Map<String,Object> GetUserDetails(String PhoneNumber){
        Connection conn=InitiateDatabaseConnection();
        Map<String,Object> rsMap=null;

        PreparedStatement stmt=null;
        ResultSet rs=null;
        if(conn==null){
            return rsMap;
        }


        try{
            String sql="SELECT * FROM Users WHERE PhoneNumber=?;";
            stmt= conn.prepareStatement(sql);
            stmt.setObject(1,PhoneNumber);
            rs=stmt.executeQuery();
            if(rs!=null){
                System.out.println("select operation is succesful!!");
                rsMap=new HashMap<>();
                rsMap.put("conn",conn);
                rsMap.put("stmt",stmt);
                rsMap.put("rs",rs);
            }


        }
        catch (SQLException ex){
            ex.printStackTrace();
        }
        catch (Exception e) {
            e.printStackTrace();
        }
        return rsMap;
    }



    public static boolean IsNewUserName(Context context,String UserName){
        Connection conn=InitiateDatabaseConnection();
        boolean isSuccess=false;
        try {
            if(conn==null||conn.isClosed()){
                return isSuccess;
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }


        PreparedStatement stmt=null;

        ResultSet rs=null;
        String sql=null;


        try {
            sql="SELECT UserID FROM Users Where UserName=?;";
            stmt=conn.prepareStatement(sql);
            stmt.setObject(1,UserName);
            rs=stmt.executeQuery();

            if(rs.next()){
                isSuccess=false;
            }
            else{
                isSuccess=true;
            }


        } catch (SQLException e) {
            e.printStackTrace();
        }
        catch (Exception e){
            e.printStackTrace();
        }

        return isSuccess;

    }



    public static boolean IsNewPhoneNumber(Context context,String Phonenumber){
        Connection conn=InitiateDatabaseConnection();
        boolean isSuccess=false;
        try {
            if(conn==null||conn.isClosed()){
                return isSuccess;
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }


        PreparedStatement stmt=null;

        ResultSet rs=null;
        String sql=null;


        try {
            sql="SELECT UserID FROM Users Where PhoneNumber=?;";
            stmt=conn.prepareStatement(sql);
            stmt.setObject(1,Phonenumber);
            rs=stmt.executeQuery();

            if(rs.next()){
                isSuccess=false;
            }
            else{
                isSuccess=true;
            }


        } catch (SQLException e) {
            e.printStackTrace();
        }
        catch (Exception e){
            e.printStackTrace();
        }

        return isSuccess;

    }

    public static boolean GetReports(Context context){
        Connection conn=InitiateDatabaseConnection();
        try {
            if(conn==null||conn.isClosed()){
                return false;
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        PreparedStatement stmt=null;
        ResultSet rs=null;
        String sql=null;

        try {
            sql="SELECT Reports FROM Users WHERE PhoneNumber=?;";
            stmt=conn.prepareStatement(sql);
            stmt.setObject(1,context.getSharedPreferences(String.valueOf(R.string.userpreference),Context.MODE_PRIVATE).getString(String.valueOf(R.string.contact),null));
            rs=stmt.executeQuery();

            if(rs!=null){
                if(rs.next()){
                    if(ReportManager.IsSuspecious(rs.getString(REPORTS))){
                        MediContract.ShowToast(context,context.getString(R.string.your_account_has_been_suspicious));
                        return false;
                    }
                    else{
                        return true;
                    }
                }
            }


        } catch (SQLException e) {
            e.printStackTrace();
        }
        catch (Exception e){
            e.printStackTrace();
        }
        return false;

    }

    public static void ReportAccount(Context context,String PhoneNumber){
        Connection conn=InitiateDatabaseConnection();
        try {
            if(conn==null||conn.isClosed()){
                MediContract.ShowToast(context,context.getString(R.string.report_failed));
                return;
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        PreparedStatement stmt=null;
        String sql=null;
        ResultSet rs=null;

        try {
            String PHONE_NUMBER=context.getSharedPreferences(String.valueOf(R.string.userpreference),Context.MODE_PRIVATE).getString(String.valueOf(R.string.contact),null);

            sql="SELECT Reports FROM Users WHERE PhoneNumber=?;";
            stmt=conn.prepareStatement(sql);
            stmt.setObject(1,PhoneNumber);
            rs=stmt.executeQuery();



            String newReport=null;
            if(rs!=null){
                if(rs.next()){
                    if(ReportManager.isAlreadyReported(rs.getString(REPORTS),PHONE_NUMBER)){
                        Log.d(LOG_TAG,"Already reported");
                        MediContract.ShowToast(context,context.getString(R.string.account_reported));
                        return;
                    }

                   newReport=ReportManager.AppendReport(rs.getString(REPORTS),PHONE_NUMBER);

                    sql="UPDATE Users SET Reports=? WHERE PhoneNumber=?;";
                    stmt=conn.prepareStatement(sql);
                    stmt.setObject(1,newReport);
                    stmt.setObject(2,PhoneNumber);
                    if(stmt.executeUpdate()==1){
                        MediContract.ShowToast(context,context.getString(R.string.account_reported));
                    }
                    else{
                        MediContract.ShowToast(context,context.getString(R.string.report_failed));
                    }

                }
                else{
                    Log.d(LOG_TAG,"Account not found");
                    MediContract.ShowToast(context,context.getString(R.string.account_reported));
                }
            }




        } catch (SQLException e) {
            if(e.getErrorCode()==1406){
                MediContract.ShowToast(context,context.getString(R.string.account_reported));
            }
            e.printStackTrace();
        }
        catch (Exception e){
            e.printStackTrace();
        }

    }

    public static boolean DeleteUser(Context context,String Phonenumber){

        //boolean returned in this function is wrong
        Connection conn=InitiateDatabaseConnection();
        boolean isSuccess=false;
        try {
            if(conn==null||conn.isClosed()){
                return isSuccess;
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }


        PreparedStatement stmt=null;

        String sql=null;


        try {
            sql="DELETE FROM Users Where PhoneNumber=?;";
            stmt=conn.prepareStatement(sql);
            stmt.setObject(1,Phonenumber);
            stmt.execute();

        } catch (SQLException e) {
            e.printStackTrace();
        }
        catch (Exception e){
            e.printStackTrace();
        }

        return isSuccess;

    }

    public static void DBclose(Connection conn){
        try{
            conn.close();
        }
        catch (Exception e){
            e.printStackTrace();
        }
    }
    public static void DBclose(ResultSet rs){
        try{
            rs.close();
        }
        catch (Exception e){
            e.printStackTrace();
        }
    }

    public static void DBclose(PreparedStatement stmt) {
        try {
            stmt.close();
        } catch (Exception e) {
            e.printStackTrace();
        }

    }


}
