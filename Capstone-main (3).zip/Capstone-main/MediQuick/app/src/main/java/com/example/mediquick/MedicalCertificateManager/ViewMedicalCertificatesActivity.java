package com.example.mediquick.MedicalCertificateManager;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.example.mediquick.Contract.MediContract;
import com.example.mediquick.R;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.ValueEventListener;

public class ViewMedicalCertificatesActivity extends AppCompatActivity {

    private static final String LOG_TAG = ViewMedicalCertificatesActivity.class.getSimpleName();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view_medical_certificates);

        EditText phnoEditText = findViewById(R.id.enter_contact_edit_text);


        ((Button) findViewById(R.id.download_button)).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                String phNo = phnoEditText.getText().toString().trim();

                if(phNo == null || phNo.isEmpty() || phNo.length() == 0){
                    ShowToast(getString(R.string.please_fill_all_fields));
                    return;
                }

                phNo = "+91" + phNo;

                MediContract.firebaseDatabase.getReference().child("medical_certificates").child(phNo).addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot snapshot) {
                        if(!snapshot.exists()){
                            ShowToast(getString(R.string.medical_certificates_not_found));
                            return;
                        }

                        String uriString = snapshot.getValue().toString();

                        try{
                            Intent i = new Intent(Intent.ACTION_VIEW);
                            i.setData(Uri.parse(uriString));
                            startActivity(i);
                        }catch (Exception e){
                            Log.d(LOG_TAG, String.valueOf(e));
                        }


                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError error) {

                    }
                });

            }
        });

    }

    private void ShowToast(String message){
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                Toast.makeText(getApplicationContext(),message,Toast.LENGTH_SHORT).show();
            }
        });
    }


}