package com.example.mediquick.Utils;

import android.Manifest;
import android.app.Activity;
import android.content.ComponentName;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.location.LocationManager;
import android.net.ConnectivityManager;
import android.net.NetworkCapabilities;
import android.net.NetworkInfo;
import android.net.Uri;
import android.os.Build;
import android.provider.Settings;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.core.content.ContextCompat;

import com.example.mediquick.AccountManager.OneTimeUserActivity;
import com.example.mediquick.AccountManager.account2;
import com.example.mediquick.R;


public class NetworkPermissionManager {

    private static final String TAG = NetworkPermissionManager.class.getSimpleName();
    private static AlertDialog builder;


    public static boolean checkInternetConnection(Context context){
        ConnectivityManager connectivityManager = (ConnectivityManager) context.getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo networkInfo=connectivityManager.getActiveNetworkInfo();
        NetworkCapabilities networkCapabilities=null;
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.M) {
            networkCapabilities=connectivityManager.getNetworkCapabilities(connectivityManager.getActiveNetwork());
        }

        int downspeed=0;
        int upspeed=0;
        if(networkCapabilities!=null){
            downspeed=networkCapabilities.getLinkDownstreamBandwidthKbps();
            upspeed=networkCapabilities.getLinkUpstreamBandwidthKbps();
        }

        if ( (networkInfo != null) && (networkInfo.isConnected())){
            if(downspeed>5 && upspeed>2){
                Log.v(TAG,"internet XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
                return true;
            }
            else {
                Log.v(TAG,"Slow internet XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
                return false;
            }
        } else {
            Log.v(TAG,"no internet XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
            return  false;
        }

    }
    public static boolean checkLocationPermission(Context context) {
        if(Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q){
            return checkBackgroundLocationPermission(context);
        }
        else{
            return checkForegroundLocationPermission(context);
        }
    }

    public static boolean checkForegroundLocationPermission(Context context) {
        if (ContextCompat.checkSelfPermission(context, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED) {
            return true;
        }

        View view= LayoutInflater.from(context).inflate(R.layout.alert_layout,null);
        ImageView imageView2;
        ImageView imageView3;
        Button buttonView;
        imageView2 = view.findViewById(R.id.denied_image);
        imageView2.setImageResource(R.drawable.denied_image);
        imageView2.setVisibility(View.GONE);
        imageView3 = view.findViewById(R.id.allow_image);
        imageView3.setImageResource(R.drawable.location_permission_android10below);

        buttonView=view.findViewById(R.id.button_view);
        buttonView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.fromParts("package", context.getPackageName(), null));
                ((Activity) context).startActivityForResult(intent, 0);
                builder.dismiss();
            }
        });


        builder=new AlertDialog.Builder(context)
                .setTitle(context.getString(R.string.location_permission_needed))
                .setMessage(context.getString(R.string.please_select_allow))
                .setCancelable(false)
                .setView(view)
                .create();
        builder.show();
        return false;

    }
    public static boolean checkBackgroundLocationPermission(Context context) {
        if (ContextCompat.checkSelfPermission(context, Manifest.permission.ACCESS_BACKGROUND_LOCATION) == PackageManager.PERMISSION_GRANTED) {
            return true;
        }


        View view= LayoutInflater.from(context).inflate(R.layout.alert_layout,null);
        ImageView imageView2;
        ImageView imageView3;
        Button buttonView;

        imageView2 = view.findViewById(R.id.denied_image);
        imageView2.setImageResource(R.drawable.denied_image);
        imageView2.setVisibility(View.VISIBLE);
        imageView3 = view.findViewById(R.id.allow_image);
        imageView3.setImageResource(R.drawable.location_permission_android10above);
        buttonView=view.findViewById(R.id.button_view);
        buttonView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.fromParts("package", context.getPackageName(), null));
                ((Activity) context).startActivityForResult(intent, 0);
                builder.dismiss();
            }
        });


        builder=new AlertDialog.Builder(context,R.style.MyDialogTheme)
                .setTitle(context.getString(R.string.location_permission_needed))
                .setMessage(context.getString(R.string.please_select_allow_all_time))
                .setView(view)
                .setCancelable(false)
                .create();

        builder.show();


        return false;
    }

    public static void getPolicyAgreement(Context context,String phone_number) {

        View view= LayoutInflater.from(context).inflate(R.layout.policy_agreement,null);
//        ImageView imageView2;
//        ImageView imageView3;
//        Button buttonView;
//
//        imageView2 = view.findViewById(R.id.denied_image);
//        imageView2.setImageResource(R.drawable.denied_image);
//        imageView2.setVisibility(View.VISIBLE);
//        imageView3 = view.findViewById(R.id.allow_image);
//        imageView3.setImageResource(R.drawable.location_permission_android10above);
//        buttonView=view.findViewById(R.id.button_view);
//        buttonView.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                Intent intent = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.fromParts("package", context.getPackageName(), null));
//                ((Activity) context).startActivityForResult(intent, 0);
//                builder.dismiss();
//            }
//        });


        builder=new AlertDialog.Builder(context,R.style.MyDialogTheme)
//                .setTitle(context.getString(R.string.location_permission_needed))
//                .setMessage(context.getString(R.string.please_select_allow_all_time))
                .setView(view)
                .setCancelable(false)
                .setPositiveButton(context.getString(R.string.agree), new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        Intent intent=new Intent(context, account2.class);
                        intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP| Intent.FLAG_ACTIVITY_CLEAR_TASK|Intent.FLAG_ACTIVITY_NEW_TASK);
                        intent.putExtra("phone_number",phone_number);
                        context.startActivity(intent);
                        dialogInterface.dismiss();
                    }
                })
                .setNegativeButton(context.getString(R.string.no), new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        Intent intent=new Intent(context,OneTimeUserActivity.class);
                        intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP| Intent.FLAG_ACTIVITY_CLEAR_TASK|Intent.FLAG_ACTIVITY_NEW_TASK);
                        context.startActivity(intent);
                        dialogInterface.dismiss();
                    }
                })
                .create();

        builder.show();

    }

    public static boolean checklocationAccess(Context context) {
        LocationManager manager = (LocationManager) context.getSystemService(Context.LOCATION_SERVICE);
        if (!manager.isProviderEnabled(LocationManager.GPS_PROVIDER)) {
            buildAlertMessageNoGps(context);
            return false;

        }
        return true;
    }

    private static void buildAlertMessageNoGps(Context context) {
        final AlertDialog.Builder builder = new AlertDialog.Builder(context);
        View view= LayoutInflater.from(context).inflate(R.layout.alert_gps_layout,null);
       builder.setMessage(context.getString(R.string.enable_gps))
                .setCancelable(false)
                .setView(view)
                .setPositiveButton(context.getString(R.string.enable), new DialogInterface.OnClickListener() {
                    public void onClick(final DialogInterface dialog, final int id) {
                        context.startActivity(new Intent(android.provider.Settings.ACTION_LOCATION_SOURCE_SETTINGS));
                        builder.setCancelable(true);
                        dialog.dismiss();
                    }
                });
        final AlertDialog alert = builder.create();
        alert.show();
    }

    public static boolean checkSMSPermission(Context context) {

        if (ContextCompat.checkSelfPermission(context, Manifest.permission.SEND_SMS) == PackageManager.PERMISSION_GRANTED) {
            return true;
        }

        View view = LayoutInflater.from(context).inflate(R.layout.alert_layout, null);
        ImageView imageView2;
        ImageView imageView3;
        Button buttonView;

        imageView2 = view.findViewById(R.id.denied_image);
        imageView2.setImageResource(R.drawable.denied_image);
        imageView2.setVisibility(View.VISIBLE);
        imageView3 = view.findViewById(R.id.allow_image);
        imageView3.setImageResource(R.drawable.sms_permission_android);
        buttonView = view.findViewById(R.id.button_view);
        buttonView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.fromParts("package", context.getPackageName(), null));
                ((Activity) context).startActivityForResult(intent, 0);
                builder.dismiss();
            }
        });


        builder = new AlertDialog.Builder(context, R.style.MyDialogTheme)
                .setTitle(context.getString(R.string.sms_permission_needed))
                .setMessage(context.getString(R.string.please_select_allow))
                .setView(view)
                .setCancelable(false)
                .create();

        builder.show();
        return false;
    }

    public static void checkAutoStart(Context context){
        getBuildName(context);
    }


    private static void getBuildName(Context context){
        if(Build.BRAND.equalsIgnoreCase("redmi")||Build.BRAND.equalsIgnoreCase("xiaomi") ){

            Intent intent = new Intent();
            intent.setComponent(new ComponentName("com.miui.securitycenter", "com.miui.permcenter.autostart.AutoStartManagementActivity"));
            enableAutoStart(context,intent);


        }else if(Build.BRAND.equalsIgnoreCase("Letv")){

            Intent intent = new Intent();
            intent.setComponent(new ComponentName("com.letv.android.letvsafe", "com.letv.android.letvsafe.AutobootManageActivity"));
            enableAutoStart(context,intent);

        }
        else if(Build.BRAND.equalsIgnoreCase("Honor")){

            Intent intent = new Intent();
            intent.setComponent(new ComponentName("com.huawei.systemmanager", "com.huawei.systemmanager.optimize.process.ProtectActivity"));
            enableAutoStart(context,intent);

        }
        if (Build.MANUFACTURER.equalsIgnoreCase("oppo")) {
            try {
                Intent intent = new Intent();
                intent.setClassName("com.coloros.safecenter",
                        "com.coloros.safecenter.permission.startup.StartupAppListActivity");
                enableAutoStart(context,intent);
            } catch (Exception e) {
                try {
                    Intent intent = new Intent();
                    intent.setClassName("com.oppo.safe",
                            "com.oppo.safe.permission.startup.StartupAppListActivity");
                    enableAutoStart(context,intent);

                } catch (Exception ex) {
                    try {
                        Intent intent = new Intent();
                        intent.setClassName("com.coloros.safecenter",
                                "com.coloros.safecenter.startupapp.StartupAppListActivity");
                        enableAutoStart(context,intent);
                    } catch (Exception exx) {

                    }
                }
            }
        }
        else if(Build.MANUFACTURER.equalsIgnoreCase("vivo")) {
            try {
                Intent intent = new Intent();
                intent.setComponent(new ComponentName("com.iqoo.secure",
                        "com.iqoo.secure.ui.phoneoptimize.AddWhiteListActivity"));
                enableAutoStart(context,intent);
            } catch (Exception e) {
                try {
                    Intent intent = new Intent();
                    intent.setComponent(new ComponentName("com.vivo.permissionmanager",
                            "com.vivo.permissionmanager.activity.BgStartUpManagerActivity"));
                    enableAutoStart(context,intent);
                } catch (Exception ex) {
                    try {
                        Intent intent = new Intent();
                        intent.setClassName("com.iqoo.secure",
                                "com.iqoo.secure.ui.phoneoptimize.BgStartUpManager");
                        enableAutoStart(context,intent);
                    } catch (Exception exx) {
                        ex.printStackTrace();
                    }
                }
            }

        }

    }

    private static void enableAutoStart(Context context,Intent intent) {

            new AlertDialog.Builder(context)
                    .setTitle(context.getString(R.string.enable_autostart))
                    .setMessage(context.getString(R.string.need_to_run_in_bg))
                    .setCancelable(false)
                    .setPositiveButton(context.getString(R.string.enable), new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            try {
                                context.startActivity(intent);
                            } catch (Exception e) {
                                Toast.makeText(context, context.getString(R.string.cant_perform_this_action), Toast.LENGTH_SHORT).show();
                            }
                            dialog.dismiss();
                        }
                    })
                    .create()
                    .show();
        }





}
