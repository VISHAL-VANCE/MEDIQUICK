package com.example.mediquick.Contract;

import android.app.Activity;
import android.app.ActivityManager;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.provider.BaseColumns;
import android.util.Log;
import android.view.View;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;

import com.example.mediquick.BackgroundTasks.LocationUpdate;
import com.example.mediquick.NotificationManager.NotificationsActivity;
import com.example.mediquick.R;
import com.google.android.material.progressindicator.CircularProgressIndicator;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.storage.FirebaseStorage;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

public class MediContract {

    private static final String LOG_TAG = MediContract.class.getSimpleName();

    public static final FirebaseDatabase firebaseDatabase=FirebaseDatabase.getInstance();
    public static final FirebaseStorage firebaseStorage = FirebaseStorage.getInstance();

    public static final String USERS="users";
    public static final String LOCATION="location";
    public static final String LATITUDE="latitude";
    public static final String LONGITUDE="longitude";
    public static final String TRIGGER="trigger";

    public static final String DETAILS="details";
    public static final String NAME="name";
    public static final String AGE="age";
    public static final String GENDER="gender";
    public static final String BLOODGROUP="bloodgroup";
    public static final String CONTACT ="contact";
    public static final String RCONTACT="rcontact";
    public static final String ADDRESS="address";
    public static final String USER_TYPE="user_type";
    public static final String PROFESSION="profession";


    public static final int DISTANCE_LIMIT =5;//km

    public static final int MAX_REPORT=3;

    public static final String TABLE_NAME="medi";
    public static final String TABLE_ID= BaseColumns._ID;
    public static final String TIME="time";
    public static final String DATE="date";
    public static final String RESPONSE="response";
    public static final String ACCEPTED="accepted";
    public static final String REJECTED="rejected";
    public static final String MISSED="missed";
    public static final String ADDITIONAL_INFO="additional_info";
    public static final String PROBLEM="problem";

    public static final String ALERT="alert";
    public static final String ACCEPTED_USERS="accepted_users";
    public static final String ALERT_LIFE="alert_life";

    public static final String PROB_TABLE_NAME="prob";
    public static final String PROB_TABLE_ID= BaseColumns._ID;
    public static final String PROB_NAME="name";
    public static final String PROB_IMAGE="image";

    public static final ArrayList<String> ACCEPTED_USERS_ARRAY=new ArrayList<String>();

    public static final String AUTHORITY="com.example.mediquick";
    public static final Uri BASE_URI=Uri.parse("content://"+AUTHORITY);
    public static final Uri FINAL_URI= Uri.withAppendedPath(BASE_URI,TABLE_NAME);

    public static final long EXCEEDING_TIME_LIMIT=15;

    public static final String GROUPS="groups";
    public static final String CHATS="chats";


    public static final String deleted_msg="Message Deleted";

    public static Boolean iDestroy=false;

    public static enum UserVerificationStatus {VERIFIED, PENDING, NOT_REQUESTED};

    public static double distance(double lat1, double lat2, double lon1, double lon2)
    {

        lon1 = Math.toRadians(lon1);
        lon2 = Math.toRadians(lon2);
        lat1 = Math.toRadians(lat1);
        lat2 = Math.toRadians(lat2);

        double dlon = lon2 - lon1;
        double dlat = lat2 - lat1;
        double a = Math.pow(Math.sin(dlat / 2), 2) + Math.cos(lat1) * Math.cos(lat2) * Math.pow(Math.sin(dlon / 2),2);
        double c = 2 * Math.asin(Math.sqrt(a));
        double r = 6371;

        return(c*r*1000);
    }



    public static void onBackPress(Context context) {
        Activity activity=(Activity) context;


        new AlertDialog.Builder(context)
                .setTitle(context.getString(R.string.exit))
                .setCancelable(false)
                .setPositiveButton(context.getString(R.string.yes), new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        activity.finish();
                        if(NotificationsActivity.fa!=null){
                            NotificationsActivity.fa.finish();
                        }
                    }
                })
                .setNegativeButton(context.getString(R.string.no), new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        dialogInterface.dismiss();
                    }
                })
                .create()
                .show();
    }

    public static String getTime(Context context,long time)
    {
        Date d = new Date(time);
        SimpleDateFormat sdf = new SimpleDateFormat("HH:mm");
        SimpleDateFormat ampm_sdf=new SimpleDateFormat("aa");

        if(ampm_sdf.format(d).equals("am")){
            return sdf.format(d)+" "+context.getString(R.string.am);
        }
        else{
            return sdf.format(d)+" "+context.getString(R.string.pm);
        }

    }


    public static String getDate(long time)
    {
        Date d = new Date(time);
        SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
        return sdf.format(d);
    }


    public static void startBackgroundService(Context context) {
        if (isBackgroundServiceRunning(context)) {
            Log.d("SplashActivity", "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX " + "Yes bg running");

        } else {
            Log.d("SplashActivity", "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX " + "NO. bg is not running");
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                Log.d("SplashActivity", "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX" + " Foreground Service called from MainActivity");
                context.startForegroundService(new Intent(context, LocationUpdate.class));

            } else {
                context.startService(new Intent(context, LocationUpdate.class));
            }
        }

    }

    public static boolean isBackgroundServiceRunning(Context context){
        ActivityManager activityManager = (ActivityManager) context.getSystemService(Context.ACTIVITY_SERVICE);
        for (ActivityManager.RunningServiceInfo service : activityManager.getRunningServices(Integer.MAX_VALUE)) {
            if (LocationUpdate.class.getName().equals(service.service.getClassName())) {
                return true;
            }
        }
        return false;
    }

    public static void stopBackgroundService(Context context){
        try{
            Intent bgService_intent=new Intent(context, LocationUpdate.class);
            context.stopService(bgService_intent);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }


    public static void ShowToast(Context context,String message){
        new Handler(Looper.getMainLooper()).post(new Runnable() {
            public void run() {
                Toast.makeText(context,message,Toast.LENGTH_SHORT).show();
            }
        });
    }

    public static void hideProgressBar(Context context, View mainView, CircularProgressIndicator progressBar){

        try{
            ((Activity) context).runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    try{
                        mainView.setVisibility(View.VISIBLE);
                        progressBar.setVisibility(View.GONE);
                    }catch (Exception e){
                        Log.e(LOG_TAG, String.valueOf(e));
                    }

                }
            });
        }catch (Exception e){
            Log.e(LOG_TAG, String.valueOf(e));
        }


    }

    public static void showProgressBar(Context context, View mainView, CircularProgressIndicator progressBar){
        try{
            ((Activity) context).runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    try{
                        mainView.setVisibility(View.GONE);
                        progressBar.setVisibility(View.VISIBLE);
                    }catch (Exception e){
                        Log.e(LOG_TAG, String.valueOf(e));
                    }

                }
            });
        }
        catch (Exception e){
            Log.e(LOG_TAG, String.valueOf(e));
        }

    }







}
