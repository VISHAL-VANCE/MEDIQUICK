package com.example.mediquick.AccountManager;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.mediquick.CloudDatabaseManager.DatabaseOperations;
import com.example.mediquick.R;
import com.example.mediquick.SettingsActivity;
import com.example.mediquick.Utils.NetworkPermissionManager;
import com.google.firebase.database.DatabaseReference;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Set;

public class ProfileEditActivity extends AppCompatActivity {

    private EditText edit_user_name;
    private Button finish_button;
//    private Spinner prof_spinner;
    private Spinner gender_spinner;
    private Spinner bloodgrp_spinner;
//    private String profession;
    private String gender;
    private String bloodgrp;
    private String phone_number;
    private String  prevstarted="";
    private EditText age;
    private EditText ad_phno1;
    private EditText ad_phno2;
    private EditText ad_phno3;
    private EditText address;

    private ProgressBar finishProgressBar;

    private SharedPreferences sharedPreferences;
    private DatabaseReference databaseReference;

    private String USER_NAME;

    private String user_name;
    private  String age_String;
    private  ArrayList<String> ad_phno_array=new ArrayList<String>();
    private String address_String;

    public static Activity fa;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile_edit);

        fa=ProfileEditActivity.this;

        edit_user_name=findViewById(R.id.user_name);
        finish_button=findViewById(R.id.finish_button);
//        prof_spinner=findViewById(R.id.prof_spinner);
        gender_spinner=findViewById(R.id.gender_spinner);
        bloodgrp_spinner=findViewById(R.id.bloodgrp_spinner);
        age=findViewById(R.id.age);
        ad_phno1=findViewById(R.id.rcontact1);
        ad_phno2=findViewById(R.id.rcontact2);
        ad_phno3=findViewById(R.id.rcontact3);
        address=findViewById(R.id.address);

        finishProgressBar=findViewById(R.id.finish_progress_bar);

        sharedPreferences=getSharedPreferences(String.valueOf(R.string.userpreference),MODE_PRIVATE);
        phone_number=sharedPreferences.getString(String.valueOf(R.string.contact),"NO NUMBER");
        USER_NAME=sharedPreferences.getString(String.valueOf(R.string.username),"NO NAME");

//        setUpProfSpinner();
        setUpGenderSpinner();
        setUpBloodgrpSpinner();

        setSharedPreferenceValues();


        finish_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showProgressBar(finish_button,finishProgressBar);
                if(!NetworkPermissionManager.checkInternetConnection(ProfileEditActivity.this)) {
                    Toast.makeText(ProfileEditActivity.this, getString(R.string.check_internet_connection), Toast.LENGTH_SHORT).show();
                    hideProgressBar(finish_button,finishProgressBar);
                    return;
                }
                String user_name=edit_user_name.getText().toString().trim();
                if(user_name.length()<3||user_name.isEmpty()||user_name.equals("You")){
                    Toast.makeText(ProfileEditActivity.this, getString(R.string.invalid_user_name), Toast.LENGTH_SHORT).show();
                    hideProgressBar(finish_button,finishProgressBar);
                    return;
                }

                updateDatabase();

            }
        });
    }


//
//    public void setUpProfSpinner(){
//
//        ArrayAdapter spinnerAdapter=ArrayAdapter.createFromResource(this,R.array.prof_spinner_array,android.R.layout.simple_spinner_item);
//        spinnerAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
//
//        prof_spinner.setAdapter(spinnerAdapter);
//
//        prof_spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
//            @Override
//            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
//                String selection = (String) parent.getItemAtPosition(position);
//                if(!selection.isEmpty()){
//                    profession=selection;
//                }
//            }
//
//            @Override
//            public void onNothingSelected(AdapterView<?> parent) {
//
//            }
//        });
//
//    }

    public void setUpGenderSpinner(){

        ArrayAdapter spinnerAdapter=ArrayAdapter.createFromResource(this,R.array.gender_spinner_array,android.R.layout.simple_spinner_item);
        spinnerAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);

        gender_spinner.setAdapter(spinnerAdapter);

        gender_spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                String selection = (String) parent.getItemAtPosition(position);
                if(!selection.isEmpty()){
                    gender=selection;
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });

    }

    public void setUpBloodgrpSpinner(){

        ArrayAdapter spinnerAdapter=ArrayAdapter.createFromResource(this,R.array.bloodgroup_spinner_array,android.R.layout.simple_spinner_item);
        spinnerAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);

        bloodgrp_spinner.setAdapter(spinnerAdapter);

        bloodgrp_spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                String selection = (String) parent.getItemAtPosition(position);
                if(!selection.isEmpty()){
                    bloodgrp=selection;
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });



    }


    public void updateDatabase(){
        user_name=edit_user_name.getText().toString().trim();
        age_String=age.getText().toString().trim();

        ad_phno_array.clear();
        if(ad_phno1.length()!=10){
            Toast.makeText(ProfileEditActivity.this,getString(R.string.invalid_phone_number)+" 1",Toast.LENGTH_SHORT).show();
            hideProgressBar(finish_button,finishProgressBar);
            return;
        }

        if(ad_phno2.length()!=10&&ad_phno2.length()!=0){
            Toast.makeText(ProfileEditActivity.this,getString(R.string.invalid_phone_number)+" 2",Toast.LENGTH_SHORT).show();
            hideProgressBar(finish_button,finishProgressBar);
            return;
        }
        if(ad_phno3.length()!=10&&ad_phno3.length()!=0){
            Toast.makeText(ProfileEditActivity.this,getString(R.string.invalid_phone_number)+" 3",Toast.LENGTH_SHORT).show();
            hideProgressBar(finish_button,finishProgressBar);
            return;
        }
        int j=0;
        ad_phno_array.add(j,"+91"+ad_phno1.getText().toString().trim());
        j++;
        if(ad_phno2.length()!=0){
            ad_phno_array.add(j,"+91"+ad_phno2.getText().toString().trim());
            j++;
        }
        if(ad_phno3.length()!=0){
            ad_phno_array.add(j,"+91"+ad_phno3.getText().toString().trim());
            j++;
        }



        address_String=address.getText().toString().trim();

        if(user_name.isEmpty()||age_String.isEmpty()||address_String.isEmpty()||gender.isEmpty()||bloodgrp.isEmpty()){
            Toast.makeText(ProfileEditActivity.this,getString(R.string.please_fill_all_fields),Toast.LENGTH_SHORT).show();
            hideProgressBar(finish_button,finishProgressBar);
            return;
        }


        createAccount();

    }

    public void createAccount(){
        new Thread(new Runnable() {
            @Override
            public void run() {

                if(DatabaseOperations.UpdateAllDetails(getApplicationContext(),user_name,phone_number, Integer.parseInt(age_String),gender,bloodgrp,address_String, sharedPreferences.getString(String.valueOf(R.string.usertype), null),ad_phno_array.get(0),ad_phno_array.size()>=2?ad_phno_array.get(1):null,ad_phno_array.size()>=3?ad_phno_array.get(2):null, false)){
                    ShowToast(getString(R.string.profile_updated));
                }
                else{
                    ShowToast(getString(R.string.cannot_update_profile));
                    hideProgressBar(finish_button,finishProgressBar);
                    return;
                }
                hideProgressBar(finish_button,finishProgressBar);

                SharedPreferences.Editor editor = sharedPreferences.edit();
                editor.putBoolean(prevstarted, true);
                editor.putString(String.valueOf(R.string.username),user_name);
                editor.putString(String.valueOf(R.string.age),age_String);
                editor.putString(String.valueOf(R.string.gender),gender);
                editor.putString(String.valueOf(R.string.contact),phone_number);
                editor.putString(String.valueOf(R.string.bloodgroup),bloodgrp);
                editor.putString(String.valueOf(R.string.address),address_String);

                Set<String> rSet = new HashSet<String>(ad_phno_array);
                editor.putStringSet(String.valueOf(R.string.rcontact),rSet);

                editor.apply();

                hideProgressBar(finish_button,finishProgressBar);
                finish();
                hideProgressBar(finish_button,finishProgressBar);

            }
        }).start();

    }

    public void MoveToSettingsActivity(){
        Intent intent=new Intent(ProfileEditActivity.this, SettingsActivity.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP| Intent.FLAG_ACTIVITY_CLEAR_TASK|Intent.FLAG_ACTIVITY_NEW_TASK);
        startActivity(intent);
    }

    private void setSharedPreferenceValues(){
        edit_user_name.setText(sharedPreferences.getString(String.valueOf(R.string.username),"NO NAME"));
        age.setText(sharedPreferences.getString(String.valueOf(R.string.age),"NO AGE"));
        address.setText(sharedPreferences.getString(String.valueOf(R.string.address),"NO ADDRESS"));

        Set<String> rset=sharedPreferences.getStringSet(String.valueOf(R.string.rcontact),null);
        int i=1;
        for(String r:rset){
            if(i==1){
                ad_phno1.setText(r.substring(3));
            }
            if(i==2){
                ad_phno2.setText(r.substring(3));
            }
            if(i==3){
                ad_phno3.setText(r.substring(3));
            }
            i++;
        }

        gender_spinner.setSelection(getSpinnerPosition(gender_spinner,sharedPreferences.getString(String.valueOf(R.string.gender),"EMPTY")));
        bloodgrp_spinner.setSelection(getSpinnerPosition(bloodgrp_spinner,sharedPreferences.getString(String.valueOf(R.string.bloodgroup),"EMPTY")));
//        prof_spinner.setSelection(getSpinnerPosition(prof_spinner,sharedPreferences.getString(String.valueOf(R.string.usertype),"EMPTY")));
    }

    private int getSpinnerPosition(Spinner spinner,String string){
        return ((ArrayAdapter) spinner.getAdapter()).getPosition(string);
    }
    private void hideProgressBar(Button button,ProgressBar progressBar){
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                button.setVisibility(View.VISIBLE);
                progressBar.setVisibility(View.GONE);
            }
        });

    }

    private void showProgressBar(Button button,ProgressBar progressBar){
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                button.setVisibility(View.GONE);
                progressBar.setVisibility(View.VISIBLE);
            }
        });

    }

    private void ShowToast(String message){
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                Toast.makeText(getApplicationContext(),message,Toast.LENGTH_SHORT).show();
            }
        });
    }
}