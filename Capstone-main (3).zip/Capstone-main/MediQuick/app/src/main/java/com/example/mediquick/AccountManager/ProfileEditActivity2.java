package com.example.mediquick.AccountManager;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.Toast;

import com.example.mediquick.CloudDatabaseManager.DatabaseOperations;
import com.example.mediquick.Contract.MediContract;
import com.example.mediquick.MainActivity;
import com.example.mediquick.R;
import com.example.mediquick.SettingsActivity;
import com.example.mediquick.Utils.NetworkPermissionManager;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

public class ProfileEditActivity2 extends AppCompatActivity {

    private Button first_aid_finish_button;

    private CheckBox heart_attack_check_box;
    private CheckBox snake_bite_check_box;
    private CheckBox bleeding_check_box;
    private CheckBox drowned_check_box;
    private CheckBox stroke_check_box;
    private CheckBox convulsions_check_box;
    private CheckBox burns_check_box;
    private CheckBox traumaticheadinjury_check_box;



    private String phone_number;


    private SharedPreferences sharedPreferences;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile_edit2);

        sharedPreferences = getSharedPreferences(String.valueOf(R.string.userpreference), MODE_PRIVATE);
        phone_number=sharedPreferences.getString(String.valueOf(R.string.contact),"NO NUMBER");
        heart_attack_check_box = findViewById(R.id.heart_attack_check_box);
        bleeding_check_box = findViewById(R.id.bleeding_check_box);
        snake_bite_check_box = findViewById(R.id.snake_Bite_check_box);
        drowned_check_box = findViewById(R.id.drowned_check_box);
        stroke_check_box = findViewById(R.id.stroke_check_box);
        convulsions_check_box = findViewById(R.id.convulsions_check_box);
        burns_check_box = findViewById(R.id.burns_check_box);
        traumaticheadinjury_check_box = findViewById(R.id.traumaticheadinjury_check_box);

//        setChecked();

        first_aid_finish_button = findViewById(R.id.first_aid_finish_button);
        first_aid_finish_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (!NetworkPermissionManager.checkInternetConnection(ProfileEditActivity2.this)) {
                    Toast.makeText(ProfileEditActivity2.this, getString(R.string.check_internet_connection), Toast.LENGTH_SHORT).show();
                    return;
                }

                List<String> firstAidList=new ArrayList<String>();

                if(heart_attack_check_box.isChecked()){
                    firstAidList.add(getString(R.string.HEART_ATTACK_STRING));
                }
                if(snake_bite_check_box.isChecked()){
                    firstAidList.add(getString(R.string.SNAKE_BITE_STRING));
                }
                if(bleeding_check_box.isChecked()){
                    firstAidList.add(getString(R.string.BLEEDING_STRING));
                }
                if(drowned_check_box.isChecked()){
                    firstAidList.add(getString(R.string.DROWNED_STRING));
                }
                if(stroke_check_box.isChecked()){
                    firstAidList.add(getString(R.string.STROKE_STRING));
                }
                if(convulsions_check_box.isChecked()){
                    firstAidList.add(getString(R.string.CONVULSIONS_STRING));
                }
                if(burns_check_box.isChecked()){
                    firstAidList.add(getString(R.string.BURNS_STRING));
                }
                if(traumaticheadinjury_check_box.isChecked()){
                    firstAidList.add(getString(R.string.TRAUMATIC_HEAD_INJURY_STRING));
                }


                String firstAidString=null;
                for(int i=0;i<firstAidList.size();i++){
                    if(firstAidString==null){
                        firstAidString=firstAidList.get(i);
                    }
                    else{
                        firstAidString+=firstAidList.get(i);
                    }

                    if(i!=firstAidList.size()-1){
                        firstAidString+=",";
                    }
                }

                updateDatabase(firstAidString);

            }

        });
    }

    public void updateDatabase(String firstAidString) {

        new Thread(new Runnable() {
            @Override
            public void run() {

                if(DatabaseOperations.UpdateFirstAid(getIntent().getStringExtra("phone_number"),firstAidString)){
                    ShowToast(getString(R.string.profile_updated));
                }
                else{
                   ShowToast(getString(R.string.cannot_update_first_aid_techniques));
                    return;
                }
                //MoveToSettingsActivity();
                finish();
            }
        }).start();


    }

//    private void setChecked(){
//            MediContract.firebaseDatabase.getReference().child(MediContract.USERS).child(phone_number).child(MediContract.PROFESSION).addListenerForSingleValueEvent(new ValueEventListener() {
//                @Override
//                public void onDataChange(@NonNull DataSnapshot snapshot) {
//                    if(snapshot.hasChild(getResources().getString(R.string.HEART_ATTACK_STRING))){
//                        heart_attack_check_box.setChecked(true);
//                    }
//                    if(snapshot.hasChild(getResources().getString(R.string.SNAKE_BITE_STRING))){
//                        snake_bite_check_box.setChecked(true);
//                    }
//                    if(snapshot.hasChild(getResources().getString(R.string.BLEEDING_STRING))){
//                        bleeding_check_box.setChecked(true);
//                    }
//                    if(snapshot.hasChild(getResources().getString(R.string.DROWNED_STRING))){
//                        drowned_check_box.setChecked(true);
//                    }
//                    if(snapshot.hasChild(getResources().getString(R.string.STROKE_STRING))){
//                        stroke_check_box.setChecked(true);
//                    }
//                    if(snapshot.hasChild(getResources().getString(R.string.CONVULSIONS_STRING))){
//                        convulsions_check_box.setChecked(true);
//                    }
//                    if(snapshot.hasChild(getResources().getString(R.string.BURNS_STRING))){
//                        burns_check_box.setChecked(true);
//                    }
//                    if(snapshot.hasChild(getResources().getString(R.string.TRAUMATIC_HEAD_INJURY_STRING))){
//                        traumaticheadinjury_check_box.setChecked(true);
//                    }
//
//                }
//
//                @Override
//                public void onCancelled(@NonNull DatabaseError error) {
//
//                }
//            });
//    }

    public void MoveToSettingsActivity() {
        Intent i = new Intent(ProfileEditActivity2.this, SettingsActivity.class);
        startActivity(i);
        finish();
    }
    private void ShowToast(String message){
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                Toast.makeText(getApplicationContext(),message,Toast.LENGTH_SHORT).show();
            }
        });
    }

}