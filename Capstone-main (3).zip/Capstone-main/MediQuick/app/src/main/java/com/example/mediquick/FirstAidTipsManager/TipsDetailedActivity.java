package com.example.mediquick.FirstAidTipsManager;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;

import com.example.mediquick.R;
import com.example.mediquick.Utils.ImageUtils;

public class TipsDetailedActivity extends AppCompatActivity {
    TextView tips_textView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tips_detailed);

        tips_textView=findViewById(R.id.tips_text_view);

        Integer p=getIntent().getIntExtra("position",0);
        tips_textView.setText(ImageUtils.getProb_tips(p));
    }
}