package com.example.mediquick.MedicalCertificateManager;

import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;

import com.example.mediquick.Contract.MediContract;
import com.example.mediquick.FileManager.FileContract;
import com.example.mediquick.HelpManager.PermissionManager;
import com.example.mediquick.R;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;

public class UploadMedicalCertificateActivity extends AppCompatActivity {

    private static final String LOG_TAG = UploadMedicalCertificateActivity.class.getSimpleName();


    private SharedPreferences sharedPreferences;

    private static final int READ_EXTERNAL_STORAGE_PERMISSION_REQUEST_CODE = 0;
    private static final int ACTIVITY_CHOOSE_FILE = 1;

    private String phone_number;

    private Uri selectedDocUri = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_upload_medical_certificate);


        sharedPreferences=getSharedPreferences(String.valueOf(R.string.userpreference),MODE_PRIVATE);
        phone_number=sharedPreferences.getString(String.valueOf(R.string.contact), null);


        ((Button) findViewById(R.id.select_certificate_file_button)).setOnClickListener(new View.OnClickListener() {
            @RequiresApi(api = Build.VERSION_CODES.M)
            @Override
            public void onClick(View view) {
                if(PermissionManager.checkAndGetReadExternalFilesPermission(UploadMedicalCertificateActivity.this, READ_EXTERNAL_STORAGE_PERMISSION_REQUEST_CODE)){
                    chooseFile();
                }
                else{
                    ShowToast(getString(R.string.allow_file_access_permission));
                }
            }
        });

        ((Button) findViewById(R.id.upload_button)).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                MediContract.showProgressBar(UploadMedicalCertificateActivity.this, findViewById(R.id.upload_button), findViewById(R.id.progress_bar));

                if(selectedDocUri == null){
                    ShowToast(getString(R.string.select_a_file));
                    MediContract.hideProgressBar(UploadMedicalCertificateActivity.this, findViewById(R.id.upload_button), findViewById(R.id.progress_bar));

                    return;
                }


                StorageReference storageReference = MediContract.firebaseStorage.getReference().child("Medical Certificates/" + phone_number);

                UploadTask uploadTask = storageReference.putFile(selectedDocUri);

                // Register observers to listen for when the download is done or if it fails
                uploadTask.addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception exception) {
                        Log.e(LOG_TAG, String.valueOf(exception));
                        ShowToast(getString(R.string.cannot_upload_the_certificates_string));
                        MediContract.hideProgressBar(UploadMedicalCertificateActivity.this, findViewById(R.id.upload_button), findViewById(R.id.progress_bar));

                    }
                }).addOnSuccessListener(new OnSuccessListener<UploadTask.TaskSnapshot>() {
                    @Override
                    public void onSuccess(UploadTask.TaskSnapshot taskSnapshot) {

                        //add child to admin requests
                        storageReference.getDownloadUrl().addOnCompleteListener(new OnCompleteListener<Uri>() {
                            @Override
                            public void onComplete(@NonNull Task<Uri> task) {
                                String downloadUrl = task.getResult().toString();

                                MediContract.firebaseDatabase.getReference().child("medical_certificates").child(phone_number).setValue(downloadUrl).addOnSuccessListener(new OnSuccessListener<Void>() {
                                    @Override
                                    public void onSuccess(Void unused) {
                                        ShowToast(getString(R.string.file_uploaded));
                                        MediContract.hideProgressBar(UploadMedicalCertificateActivity.this, findViewById(R.id.upload_button), findViewById(R.id.progress_bar));

                                    }
                                }).addOnFailureListener(new OnFailureListener() {
                                    @Override
                                    public void onFailure(@NonNull Exception e) {
                                        Log.e(LOG_TAG, String.valueOf(e));
                                        ShowToast(getString(R.string.cannot_upload_the_certificates_string));
                                        MediContract.hideProgressBar(UploadMedicalCertificateActivity.this, findViewById(R.id.upload_button), findViewById(R.id.progress_bar));

                                    }
                                });
                            }
                        });



                    }
                });
            }
        });



    }

    private void chooseFile(){
        //handle onActivityResult
        FileContract.chooseFile(UploadMedicalCertificateActivity.this, ACTIVITY_CHOOSE_FILE);
    }

    private void ShowToast(String message){
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                Toast.makeText(getApplicationContext(),message,Toast.LENGTH_SHORT).show();
            }
        });
    }



    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (resultCode != RESULT_OK)
            return;

        if(requestCode == ACTIVITY_CHOOSE_FILE)
        {
            selectedDocUri = data.getData();

        }
    }


    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        switch (requestCode){
            case READ_EXTERNAL_STORAGE_PERMISSION_REQUEST_CODE:
                if(grantResults[0] == PackageManager.PERMISSION_GRANTED){
                    chooseFile();
                }
                else{
                    //do nothing
                }
                break;
        }
    }

}