package com.example.mediquick.AdminManager;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.example.mediquick.CloudDatabaseManager.DatabaseOperations;
import com.example.mediquick.Contract.MediContract;
import com.example.mediquick.R;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;

import java.util.ArrayList;

public class RequestAdapter extends ArrayAdapter<String[]> {
    private final String TAG= RequestAdapter.class.getSimpleName();

    private ArrayList<String[]> requestList = null;
    public RequestAdapter(@NonNull Context context, int resource, ArrayList<String[]> arrayList) {
        super(context, resource,arrayList);
        requestList = arrayList;
    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        if(convertView==null){
            convertView= LayoutInflater.from(getContext()).inflate(R.layout.request_first_aider_list_item,parent,false);
        }

        TextView textView=convertView.findViewById(R.id.mobile_number);
        textView.setText(requestList.get(position)[0]);

        ((ImageView) convertView.findViewById(R.id.document_image_button)).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                try{
                    Intent i = new Intent(Intent.ACTION_VIEW);
                    i.setData(Uri.parse(requestList.get(position)[1]));
                    getContext().startActivity(i);
                }catch (Exception e){
                    ShowToast(getContext(), getContext().getString(R.string.cannot_open_the_file));
                    Log.e(TAG, String.valueOf(e));
                }
            }
        });

        ((Button) convertView.findViewById(R.id.approve_button)).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                new Thread(new Runnable() {
                    @Override
                    public void run() {
                        if (!DatabaseOperations.UpdateUserVerificationStatus(requestList.get(position)[0], MediContract.UserVerificationStatus.VERIFIED.toString())) {
                            ShowToast(getContext(), getContext().getString(R.string.unknown_problem));
                            return;
                        }

                        MediContract.firebaseDatabase.getReference().child("admin").child(requestList.get(position)[0]).removeValue().addOnSuccessListener(new OnSuccessListener<Void>() {
                            @Override
                            public void onSuccess(Void unused) {
                                requestList.remove(position);
                                notifyDataSetChanged();
                            }
                        }).addOnFailureListener(new OnFailureListener() {
                            @Override
                            public void onFailure(@NonNull Exception e) {
                                ShowToast(getContext(), getContext().getString(R.string.unknown_problem));
                            }
                        });

                    }

                }).start();


            }
        });

        ((Button) convertView.findViewById(R.id.decline_button)).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                MediContract.firebaseDatabase.getReference().child("admin").child(requestList.get(position)[0]).removeValue().addOnSuccessListener(new OnSuccessListener<Void>() {
                    @Override
                    public void onSuccess(Void unused) {
                        new Thread(new Runnable() {
                            @Override
                            public void run() {
                                DatabaseOperations.DeleteUser(getContext(), requestList.get(position)[0]);
//                                if(!DatabaseOperations.DeleteUser(getContext(), requestList.get(position)[0])){
//                                    ShowToast(getContext(), getContext().getString(R.string.unknown_problem));
//                                    return;
//                                }
                                ((Activity) getContext()).runOnUiThread(new Runnable() {
                                    @Override
                                    public void run() {
                                        requestList.remove(position);
                                        notifyDataSetChanged();
                                    }
                                });

                            }
                        }).start();

                    }
                }).addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                        ShowToast(getContext(), getContext().getString(R.string.unknown_problem));
                    }
                });
            }
        });

        return  convertView;
    }

    public static void ShowToast(Context context,String message){
        new Handler(Looper.getMainLooper()).post(new Runnable() {
            public void run() {
                Toast.makeText(context,message,Toast.LENGTH_SHORT).show();
            }
        });
    }

}
