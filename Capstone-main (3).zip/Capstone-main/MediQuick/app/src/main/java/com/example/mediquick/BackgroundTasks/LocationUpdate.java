package com.example.mediquick.BackgroundTasks;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.AlarmManager;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.graphics.Color;
import android.location.Location;
import android.location.LocationManager;
import android.media.AudioManager;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.PowerManager;
import android.util.Log;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.app.ActivityCompat;
import androidx.core.app.NotificationCompat;

import com.example.mediquick.CloudDatabaseManager.DatabaseOperations;
import com.example.mediquick.Contract.MediContract;
import com.example.mediquick.NotificationManager.DetailedNotifyActivity;
import com.example.mediquick.R;
import com.example.mediquick.Utils.AlarmPlayerManager;
import com.example.mediquick.Utils.AlarmReceiver;
import com.example.mediquick.Utils.AlertInputManager;
import com.example.mediquick.Utils.BootReceiver;
import com.example.mediquick.Utils.NetworkPermissionManager;
import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationCallback;
import com.google.android.gms.location.LocationRequest;
import com.google.android.gms.location.LocationResult;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.location.LocationSettingsRequest;
import com.google.android.gms.location.SettingsClient;
import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import java.util.Calendar;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Timer;
import java.util.TimerTask;
import java.util.concurrent.TimeUnit;

public class LocationUpdate extends Service {
    private static SharedPreferences sharedPreferences;
    private ChildEventListener alarmChildEventListener;

    private DatabaseReference databaseReference;

    private String PHNO_NUMBER;

    private static final String TAG=LocationUpdate.class.getSimpleName();



    private FusedLocationProviderClient fusedLocationClient;
    private LocationRequest locationRequest;
    private  LocationCallback locationCallback;

    private String NOTIFICATION_CHANNEL_ID = "com.example.mediquick";
    private  String channelName = "My Background Service";


    private static final String CHANNEL_ID = "100";
    private static final String CHANNEL_ID_ALERT = "101";


    private double lat1;
    private  double lon1;


    private PowerManager powerManager;

    private PowerManager.WakeLock mWakeLock;
    private String WAKELOCK_TAG="mediQuick Wakelock";


    @Override
    public IBinder onBind(Intent intent) {
        // TODO: Return the communication channel to the service.
        throw new UnsupportedOperationException("Not yet implemented");
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                startMyOwnForeground();
                Log.d(TAG, "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX" + " onStartCommand Oreo executed");
            }
        } catch (Exception e) {
            Log.d(" Error --->> ", "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX" + e.getMessage());
        }


        //startTimer();



        databaseReference = MediContract.firebaseDatabase.getReference();
        sharedPreferences=getApplicationContext().getSharedPreferences(String.valueOf(R.string.userpreference),getApplicationContext().MODE_PRIVATE);
        PHNO_NUMBER = sharedPreferences.getString(String.valueOf(R.string.contact), "NO NAME");
        if(alarmChildEventListener!=null){
            databaseReference.child(MediContract.USERS).child(PHNO_NUMBER).child(MediContract.TRIGGER).removeEventListener(alarmChildEventListener);
        }
        try {
            UpdateLocation();
        } catch (Exception e) {
            e.printStackTrace();
        }

        try{
            CheckForTrigger();
        } catch (Exception e) {
            e.printStackTrace();
        }



        return START_STICKY;

    }

    @Override
    public void onTaskRemoved(Intent rootIntent) {

        Log.d(TAG, "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX" + " onTaskRemoved()");
        super.onTaskRemoved(rootIntent);
    }

    @Override
    public void onDestroy() {
        //stoptimertask();
        try{
            if(alarmChildEventListener!=null){
                databaseReference.child(MediContract.USERS).child(PHNO_NUMBER).child(MediContract.TRIGGER).removeEventListener(alarmChildEventListener);
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
        try{
            if(fusedLocationClient!=null) {
                fusedLocationClient.removeLocationUpdates(locationCallback);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        if(!MediContract.iDestroy){
            Intent restartIntent=new Intent(this, BootReceiver.class);
            sendBroadcast(restartIntent);
        }
        Log.d(TAG, "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX" + " onDestory()");


        super.onDestroy();
    }

    public void UpdateLocation(){

        if (ActivityCompat.checkSelfPermission(getApplicationContext(), Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED || ActivityCompat.checkSelfPermission(getApplicationContext(), Manifest.permission.ACCESS_BACKGROUND_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            return;
        }
        Log.d(TAG, "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX" + " UpdateLocation called");
        fusedLocationClient = LocationServices.getFusedLocationProviderClient(getApplicationContext());

        locationCallback = new LocationCallback() {
            @Override
            public void onLocationResult(@NonNull LocationResult locationResult) {
                Log.d(TAG, "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX" + " onLocationResult called");

                if (locationResult != null) {

                    PowerManager pm = (PowerManager)getSystemService(POWER_SERVICE);
                    PowerManager.WakeLock wl = pm.newWakeLock(PowerManager.SCREEN_BRIGHT_WAKE_LOCK | PowerManager.ACQUIRE_CAUSES_WAKEUP, TAG);
                    wl.acquire(1000*10);

                    sharedPreferences=getApplicationContext().getSharedPreferences(String.valueOf(R.string.userpreference),getApplicationContext().MODE_PRIVATE);
                    PHNO_NUMBER = sharedPreferences.getString(String.valueOf(R.string.contact), "NO NAME");


                    for (Location location : locationResult.getLocations()) {

                        lat1 = location.getLatitude();
                        lon1 = location.getLongitude();

                        Map<String, Object> locationmap = new HashMap<>();
                        locationmap.put(MediContract.LATITUDE, lat1);
                        locationmap.put(MediContract.LONGITUDE, lon1);

                        Log.d(TAG, "SSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSS "+lat1+" "+lon1);
//
//                        try {
//                            MediContract.firebaseDatabase.getReference().child(MediContract.USERS).child(PHNO_NUMBER).child(MediContract.LOCATION).updateChildren(locationmap);
//                        } catch (Exception e) {
//                            e.printStackTrace();
//                        }
                        new Thread(new Runnable() {
                            @Override
                            public void run() {
                                DatabaseOperations.UpdateLatLong(PHNO_NUMBER,lat1,lon1);
                            }
                        }).start();


                    }
                    if(wl!=null){
                        try {
                            wl.release();
                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                    }

                }
                else {
                    Log.d(TAG, "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX" + " onLocationResult NULLL");
                }




            }

        };
        Log.d(TAG, "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX" + " UpdateLocation executed");

        startLocationUpdates();


    }

    private void startLocationUpdates(){
        Log.d(TAG, "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX" + " startLocationUpdates called");

        locationRequest = new LocationRequest();
        locationRequest.setPriority(LocationRequest.PRIORITY_BALANCED_POWER_ACCURACY);
        locationRequest.setInterval(1000*60*10);
        locationRequest.setFastestInterval(1000*60*7);


        LocationSettingsRequest.Builder builder = new LocationSettingsRequest.Builder();
        builder.addLocationRequest(locationRequest);
        LocationSettingsRequest locationSettingsRequest = builder.build();

        SettingsClient settingsClient = LocationServices.getSettingsClient(getApplicationContext());
        settingsClient.checkLocationSettings(locationSettingsRequest);

        try{
            if (ActivityCompat.checkSelfPermission(getApplicationContext(), Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED || ActivityCompat.checkSelfPermission(getApplicationContext(), Manifest.permission.ACCESS_BACKGROUND_LOCATION) != PackageManager.PERMISSION_GRANTED) {

            }
            else{
                Log.d(TAG, "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX" + " fused called");
                fusedLocationClient.requestLocationUpdates(locationRequest, locationCallback, Looper.myLooper());
            }
        } catch (Exception e) {
            e.printStackTrace();
        }


    }




    private void startMyOwnForeground() {
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
            createNotificationChannel();

            NotificationChannel chan = null;

            chan = new NotificationChannel(NOTIFICATION_CHANNEL_ID, channelName, NotificationManager.IMPORTANCE_NONE);
            chan.setLightColor(Color.BLUE);
            chan.setLockscreenVisibility(Notification.VISIBILITY_PRIVATE);
            NotificationManager manager = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
            assert manager != null;
            manager.createNotificationChannel(chan);

            NotificationCompat.Builder notificationBuilder = new NotificationCompat.Builder(this, NOTIFICATION_CHANNEL_ID);
            Notification notification = notificationBuilder.setOngoing(true)
                    .setSmallIcon(R.drawable.app_icon_white_png)
                    .setContentTitle(getString(R.string.mediquick_updating_location))
                    .setPriority(NotificationManager.IMPORTANCE_MIN)
                    .setCategory(Notification.CATEGORY_SERVICE)
                    .build();
            startForeground(2, notification);

        }
    }

    private NotificationChannel createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            CharSequence name = getString(R.string.channel_name);
            String description = getString(R.string.channel_description);
            int importance = NotificationManager.IMPORTANCE_DEFAULT;
            NotificationChannel channel = new NotificationChannel(CHANNEL_ID, name, importance);
            channel.setDescription(description);

            NotificationManager notificationManager = getSystemService(NotificationManager.class);
            notificationManager.createNotificationChannel(channel);
            return channel;
        }
        return null;
    }

    public void CheckForTrigger() {
        sharedPreferences = getApplicationContext().getSharedPreferences(String.valueOf(R.string.userpreference),getApplicationContext().MODE_PRIVATE);
        PHNO_NUMBER = sharedPreferences.getString(String.valueOf(R.string.contact), "NO NAME");
        alarmChildEventListener=databaseReference.child(MediContract.USERS).child(PHNO_NUMBER).child(MediContract.TRIGGER).addChildEventListener(new ChildEventListener() {
            @Override
            public void onChildAdded(@NonNull DataSnapshot snapshot, @Nullable String previousChildName) {
                Log.d(TAG, "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX" + " Trigger Detected");
                String input = null;

                Iterator iterator=snapshot.getChildren().iterator();
                while (iterator.hasNext()){
                    input=((DataSnapshot)iterator.next()).getValue().toString();

                    if (input != null && !input.isEmpty()) {
                        AlertInputManager alertInputManager = new AlertInputManager(getApplicationContext());
                        alertInputManager.parseInputAlert(input);
                    }

                }

                databaseReference.child(MediContract.USERS).child(PHNO_NUMBER).child(MediContract.TRIGGER).setValue("0");


            }

            @Override
            public void onChildChanged(@NonNull DataSnapshot snapshot, @Nullable String previousChildName) {

            }

            @Override
            public void onChildRemoved(@NonNull DataSnapshot snapshot) {

            }

            @Override
            public void onChildMoved(@NonNull DataSnapshot snapshot, @Nullable String previousChildName) {

            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });
    }

    public static void StartAlarm(Context context,String s) {


        long incTime=Long.valueOf(s);
        long myTime= Calendar.getInstance().getTimeInMillis();

        Boolean is_alerted=sharedPreferences.getBoolean(String.valueOf(R.bool.is_alerted),false);
        if(AlarmPlayerManager.CheckIsPlaying2()||isTimeExceeded(incTime,myTime)||is_alerted){
            return;
        }

        Log.d(TAG, "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX" + " StartAlarm() Called");

        PowerManager pm = (PowerManager) context.getSystemService(context.POWER_SERVICE);
        PowerManager.WakeLock wl = pm.newWakeLock(PowerManager.SCREEN_BRIGHT_WAKE_LOCK | PowerManager.ACQUIRE_CAUSES_WAKEUP, TAG);
        wl.acquire();


        Intent intent = new Intent(context, AlarmReceiver.class);
        final int flag =  Build.VERSION.SDK_INT >= Build.VERSION_CODES.M ? PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE : PendingIntent.FLAG_UPDATE_CURRENT;
        PendingIntent pendingIntent = PendingIntent.getBroadcast(context, 0, intent,flag);
        AlarmManager alarmManager = (AlarmManager) context.getSystemService(context.ALARM_SERVICE);
        alarmManager.set(AlarmManager.RTC_WAKEUP, System.currentTimeMillis() + (1 * 1000), pendingIntent);


        setAlarmNotification(context);

        if(wl!=null){
            try {
                wl.release();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }



    }

    @SuppressLint("Range")
    public static void setAlarmNotification(Context context){
        Cursor cursor = context.getContentResolver().query(MediContract.FINAL_URI, new String[]{MediContract.TABLE_ID,MediContract.NAME}, null, null, MediContract.TABLE_ID+" DESC");
        String table_id="";
        if (cursor==null){
            return;
        }
        String name;

        if(cursor.getCount()==0){
            table_id=MediContract.TABLE_ID;
            name="Someone";
        }
        else {
            cursor.moveToFirst();
            table_id = cursor.getString(cursor.getColumnIndex(MediContract.TABLE_ID));
            name= cursor.getString(cursor.getColumnIndex(MediContract.NAME));
        }

        cursor.close();


        Intent fullScreenIntent = new Intent(context, DetailedNotifyActivity.class);
        fullScreenIntent.putExtra("table_id", table_id);
        fullScreenIntent.putExtra("alarm", 1);

        final int flag =  Build.VERSION.SDK_INT >= Build.VERSION_CODES.M ? PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE : PendingIntent.FLAG_UPDATE_CURRENT;
        PendingIntent fullScreenPendingIntent = PendingIntent.getActivity(context, 1,
                fullScreenIntent,flag);
        createNotificationChannelForAlert(context);


        NotificationCompat.Builder notificationBuilder =
                new NotificationCompat.Builder(context, CHANNEL_ID_ALERT)
                        .setSmallIcon(R.drawable.bell_icon)
                        .setContentTitle(context.getString(R.string.incomming_alert))
                        .setContentText(name)
                        .setPriority(NotificationCompat.PRIORITY_HIGH)
                        .setCategory(NotificationCompat.CATEGORY_CALL)
                        .setFullScreenIntent(fullScreenPendingIntent, true)
                        .setOngoing(false);

        Notification incomingCallNotification = notificationBuilder.build();

        NotificationManager notificationManager =
                (NotificationManager)context.getSystemService(context.NOTIFICATION_SERVICE);

        assert notificationManager != null;
        notificationManager.notify(3,incomingCallNotification);

    }

    public static void createNotificationChannelForAlert(Context context) {
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
            CharSequence name = context.getString(R.string.channel_name_alert);
            String description =context.getString(R.string.channel_description);
            int importance = NotificationManager.IMPORTANCE_DEFAULT;
            NotificationChannel channel = null;

            channel = new NotificationChannel(CHANNEL_ID_ALERT, name, importance);
            channel.setDescription(description);

            NotificationManager notificationManager = context.getSystemService(NotificationManager.class);
            notificationManager.createNotificationChannel(channel);
        }


    }

    public static Boolean isTimeExceeded(long incTime,long myTime){

        final long secondsInMilli = 1000;
        final long minutesInMilli = secondsInMilli * 60;
        final long hoursInMilli = minutesInMilli * 60;
        final long daysInMilli = hoursInMilli * 24;

        long different=myTime-incTime;

        long elapsedDays = different / daysInMilli;
        different = different % daysInMilli;

        long elapsedHours = different / hoursInMilli;
        different = different % hoursInMilli;

        long elapsedMinutes = different / minutesInMilli;
        different = different % minutesInMilli;


        if(elapsedDays!=0||elapsedHours!=0){
            return true;
        }
        if(elapsedMinutes> MediContract.EXCEEDING_TIME_LIMIT||elapsedMinutes<-MediContract.EXCEEDING_TIME_LIMIT){
            return true;
        }
        return false;

    }

    public void stopBackgroundService(){


        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            stopForeground(true); //true will remove notification
        }
    }

    private Timer timer;
    private TimerTask timerTask;
    long oldTime=0;
    public int counter=0;
    public void startTimer() {
        //set a new Timer
        timer = new Timer();

        //initialize the TimerTask's job
        initializeTimerTask();

        //schedule the timer, to wake up every 1 second
        timer.schedule(timerTask, 1000, 1000*5); //
    }

    /**
     * it sets the timer to print the counter every x seconds
     */
    public void initializeTimerTask() {
        timerTask = new TimerTask() {
            public void run() {
                Log.d("in timer", "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX in timer ++++  "+ (counter++));
                UpdateLocation();
            }
        };
    }

    /**
     * not needed
     */
    public void stoptimertask() {
        //stop the timer, if it's not already null
        if (timer != null) {
            timer.cancel();
            timer = null;
        }
    }



}