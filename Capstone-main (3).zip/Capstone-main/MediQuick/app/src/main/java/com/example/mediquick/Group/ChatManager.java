package com.example.mediquick.Group;

import java.util.ArrayList;

public class ChatManager {
    public static ArrayList<String> chatList;
    public static ArrayList<String> chatSenderList;
    public static ArrayList<Integer> chatDelList;

    public static ArrayList<Integer> DELETED_INDEX_ARRAY=new ArrayList<Integer>();
}
