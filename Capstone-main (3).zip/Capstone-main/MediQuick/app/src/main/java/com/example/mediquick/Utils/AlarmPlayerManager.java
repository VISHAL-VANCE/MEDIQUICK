package com.example.mediquick.Utils;

import android.content.Context;
import android.media.MediaPlayer;

import com.example.mediquick.Contract.MediContract;
import com.example.mediquick.R;

public class AlarmPlayerManager {

    static MediaPlayer tone;
    static MediaPlayer my_chat_sound;
    static MediaPlayer his_chat_sound;


    public static void StartMediaPlayer(Context context){
        tone=MediaPlayer.create(context, R.raw.emergency_tone);
        tone.start();
    }

    public static Boolean CheckIsPlaying(){
        if(my_chat_sound==null&&his_chat_sound==null){
            return false;
        }
        Boolean b1=false;
        Boolean b2=false;
        if(my_chat_sound!=null){
           b1=my_chat_sound.isPlaying();
        }
        if(his_chat_sound!=null){
            b2=his_chat_sound.isPlaying();
        }
        return (b1||b2);
    }

    public static Boolean CheckIsPlaying2(){
        if(tone==null){
            return false;
        }
        return tone.isPlaying();
    }

    public static void StopMediaPlayer(){
        if(CheckIsPlaying()){
            tone.stop();
        }

    }

    public static void giveMyChatBeep(Context context){
        if(!CheckIsPlaying()){
            my_chat_sound=MediaPlayer.create(context,R.raw.facebookchat);
            my_chat_sound.start();
        }

    }
    public static void giveHisChatBeep(Context context){
        if(!CheckIsPlaying()){
            his_chat_sound=MediaPlayer.create(context,R.raw.among_us_chat_sound);
            his_chat_sound.start();
        }


    }
}
