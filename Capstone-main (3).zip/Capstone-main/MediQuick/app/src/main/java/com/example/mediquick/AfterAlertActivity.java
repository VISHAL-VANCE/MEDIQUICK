package com.example.mediquick;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.example.mediquick.Contract.MediContract;
import com.example.mediquick.FirstAidTipsManager.FirstAidActivity;
import com.example.mediquick.FirstAidTipsManager.TipsDetailedActivity;
import com.example.mediquick.Group.ChatActivity;
import com.example.mediquick.Utils.ImageUtils;
import com.example.mediquick.Utils.NetworkPermissionManager;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.ValueEventListener;

import java.util.Arrays;
import java.util.Iterator;

import javax.microedition.khronos.egl.EGLDisplay;

public class AfterAlertActivity extends AppCompatActivity {
    private static final String TAG =AfterAlertActivity.class.getSimpleName();
    private ListView listView;
    private TextView emptyView;
    private AcceptedUsersAdapter acceptedUsersAdapter;
    private SharedPreferences sharedPreferences;
    //private String USERNAME;
    private String PHNO_NUMBER;
    private Button cancel_alert_button;
    private Button tipsButton;
    private Button chatsButton;
    private DatabaseReference databaseReference;
    private ValueEventListener valueEventListener;
    private String problem;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_after_alert);


        sharedPreferences=getSharedPreferences(String.valueOf(R.string.userpreference),MODE_PRIVATE);
        PHNO_NUMBER=sharedPreferences.getString(String.valueOf(R.string.contact),"NO NAME");

        databaseReference=MediContract.firebaseDatabase.getReference().child(MediContract.USERS).child(PHNO_NUMBER);

        emptyView=findViewById(R.id.emptyView);
        cancel_alert_button=findViewById(R.id.cancel_alert_button);
        tipsButton=findViewById(R.id.tips_button);
        chatsButton=findViewById(R.id.chats_button);

        listView=findViewById(R.id.accepted_users_listview);
        listView.setEmptyView(emptyView);

        acceptedUsersAdapter=new AcceptedUsersAdapter(this,0,MediContract.ACCEPTED_USERS_ARRAY);
        listView.setAdapter(acceptedUsersAdapter);


        cancel_alert_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(AfterAlertActivity.this,getString(R.string.long_press_to_cancel_alert),Toast.LENGTH_SHORT).show();

            }
        });

        cancel_alert_button.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View v) {
                if(!NetworkPermissionManager.checkInternetConnection(AfterAlertActivity.this)) {
                    Toast.makeText(AfterAlertActivity.this, getString(R.string.check_internet_connection), Toast.LENGTH_SHORT).show();
                    return false;
                }
                databaseReference.child(MediContract.ALERT).setValue("no");
                databaseReference.child(MediContract.ACCEPTED_USERS).setValue(0);
                SharedPreferences.Editor editor=sharedPreferences.edit();
                editor.putString(String.valueOf(R.string.alert_clicked),"no");
                editor.apply();

                MediContract.firebaseDatabase.getReference().child(MediContract.GROUPS).child(PHNO_NUMBER).removeValue();

                setIsAlertedFalse();

                Intent intent=new Intent(AfterAlertActivity.this,MainActivity.class);
                startActivity(intent);
                finish();
                return false;
            }
        });

        tipsButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                problem=sharedPreferences.getString("problem","Not Mentioned");
                if(problem.equals("Not Mentioned")){
                        Intent intent=new Intent(AfterAlertActivity.this, FirstAidActivity.class);
                        startActivity(intent);
                        return;
                }
                int ind=0;

                for(int i=0;i<8;i++){
                    if(problem.equals(String.valueOf(getResources().getString(ImageUtils.getProb_name(i))))){
                        ind=i;
                        break;
                    }
                }

                Intent intent=new Intent(AfterAlertActivity.this, TipsDetailedActivity.class);
                intent.putExtra("position",ind);
                startActivity(intent);
            }
        });

        chatsButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(AfterAlertActivity.this, ChatActivity.class);
                intent.putExtra("grp_name",PHNO_NUMBER);
                startActivity(intent);
            }
        });

    }

    public void checkForAcceptedUsers(){
        valueEventListener=databaseReference.child(MediContract.ACCEPTED_USERS).addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                updateList(snapshot);
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });
    }
    public void updateList(DataSnapshot snapshot){
        MediContract.ACCEPTED_USERS_ARRAY.clear();
        Iterator iterator=snapshot.getChildren().iterator();
        if(!iterator.hasNext()){
            acceptedUsersAdapter.notifyDataSetChanged();
            return;
        }
        while(iterator.hasNext()){

            String name=((DataSnapshot)iterator.next()).getKey();

            MediContract.ACCEPTED_USERS_ARRAY.add(name);
            acceptedUsersAdapter.notifyDataSetChanged();

        }
    }

    private void setIsAlertedFalse(){
        SharedPreferences.Editor editor=sharedPreferences.edit();
        editor.putBoolean(String.valueOf(R.bool.is_alerted),false);
        editor.apply();
    }

    @Override
    protected void onResume() {
        checkForAcceptedUsers();
        super.onResume();
    }

    @Override
    protected void onPause() {
        databaseReference.removeEventListener(valueEventListener);
        MediContract.ACCEPTED_USERS_ARRAY.clear();
        super.onPause();
    }

    @Override
    public void onBackPressed() {
        Toast.makeText(AfterAlertActivity.this,getString(R.string.click_cancel_alert),Toast.LENGTH_SHORT).show();
    }
}