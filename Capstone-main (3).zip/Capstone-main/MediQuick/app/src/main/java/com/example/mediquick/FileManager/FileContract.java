package com.example.mediquick.FileManager;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.util.Log;

import java.io.InputStream;

public class FileContract {

    private static final String LOG_TAG = FileContract.class.getSimpleName();

    private static String[] uploadFiletypes = new String[]{"application/pdf"};

    public static void chooseFile(Context context, int requestID){
        Intent chooseFile;
        Intent intent;
        chooseFile = new Intent(Intent.ACTION_GET_CONTENT);
        chooseFile.addCategory(Intent.CATEGORY_OPENABLE);
        chooseFile.setType(uploadFiletypes[0]);
        intent = Intent.createChooser(chooseFile, "Choose a file");
        ((Activity) context).startActivityForResult(intent, requestID);
    }

    public static InputStream getInputStreamFromUri(Context context, Uri uri){
        InputStream inputStream = null;
        try{
            inputStream = context.getContentResolver().openInputStream(uri);
        }catch (Exception e){
            Log.e(LOG_TAG, String.valueOf(e));
        }

        return inputStream;
    }

}
