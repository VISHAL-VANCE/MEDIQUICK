package com.example.mediquick.FirstAidTipsManager;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;

import com.example.mediquick.R;
import com.example.mediquick.Utils.ImageUtils;
import com.google.firebase.installations.Utils;

public class FirstAidActivity extends AppCompatActivity {
    private ListView aid_list;
    private AidAdapter aidAdapter;
    private Intent intent;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_first_aid);

        aid_list=findViewById(R.id.aid_list);
        aidAdapter=new AidAdapter(this,0, ImageUtils.prob_name);
        aid_list.setAdapter(aidAdapter);
        intent=new Intent(FirstAidActivity.this,TipsDetailedActivity.class);

        aid_list.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                intent.putExtra("position",position);
                startActivity(intent);
            }
        });
    }
}