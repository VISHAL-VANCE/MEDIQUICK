package com.example.mediquick;

import junit.framework.TestCase;

public class TestClassTest extends TestCase {

    public void testVeryCloseUsers() {
        TestClass testClass = new TestClass();
        assertTrue(testClass.CheckForDistance(12.9709598000, 79.1636494000, 12.9709597000, 79.1636493000));
    }

    public void testCloseUsers() {
        TestClass testClass = new TestClass();
        assertTrue(testClass.CheckForDistance(12.9709558000, 79.1636454000, 12.9709597000, 79.1636493000));
    }

    public void testfarUsers() {
        TestClass testClass = new TestClass();
        assertFalse(testClass.CheckForDistance(12.9301558000, 79.1696454000, 12.9709597000, 79.1636493000));
    }

    public void testVeryfarUsers() {
        TestClass testClass = new TestClass();
        assertFalse(testClass.CheckForDistance(13.9301558000, 79.1696454000, 12.9709597000, 79.1636493000));
    }
}