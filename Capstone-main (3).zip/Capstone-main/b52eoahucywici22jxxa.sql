-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: b52eoahucywici22jxxa-mysql.services.clever-cloud.com:3306
-- Generation Time: Apr 02, 2024 at 11:23 AM
-- Server version: 8.0.22-13
-- PHP Version: 8.2.16

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `b52eoahucywici22jxxa`
--

-- --------------------------------------------------------

--
-- Table structure for table `Users`
--

CREATE TABLE `Users` (
  `UserId` int(5) UNSIGNED ZEROFILL NOT NULL,
  `UserName` varchar(20) NOT NULL,
  `PhoneNumber` varchar(15) NOT NULL,
  `Age` int NOT NULL,
  `Gender` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `BloodGroup` varchar(5) NOT NULL,
  `Address` varchar(100) NOT NULL,
  `UserRole` varchar(15) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `RelativeContact1` varchar(15) NOT NULL,
  `RelativeContact2` varchar(15) DEFAULT NULL,
  `RelativeContact3` varchar(15) DEFAULT NULL,
  `FirstAidTechKnown` varchar(50) DEFAULT NULL,
  `Latitude` double(12,10) DEFAULT NULL,
  `Longitude` double(12,10) DEFAULT NULL,
  `Reports` varchar(45) DEFAULT NULL,
  `UserVerificationStatus` enum('VERIFIED','PENDING','NOT_REQUESTED') CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT 'VERIFIED'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `Users`
--

INSERT INTO `Users` (`UserId`, `UserName`, `PhoneNumber`, `Age`, `Gender`, `BloodGroup`, `Address`, `UserRole`, `RelativeContact1`, `RelativeContact2`, `RelativeContact3`, `FirstAidTechKnown`, `Latitude`, `Longitude`, `Reports`, `UserVerificationStatus`) VALUES
(00040, 'கிருத்திக்', '+917200691006', 20, 'ஆண்', 'O+', 'விஐடி மென்ஸ் ஹாஸ்டல்', 'சாதாரண நபர்', '+919361730947', NULL, NULL, NULL, 12.9709597000, 79.1636493000, NULL, 'VERIFIED'),
(00042, 'Bhuvan', '+916380642043', 18, 'Male', 'A+', 'J block 551', 'Normal people', '+919655005689', NULL, NULL, NULL, 12.9721671000, 79.1578796000, NULL, 'VERIFIED'),
(00043, 'Harivignesh', '+919655005689', 20, 'Male', 'A+', 'Salem', 'First Aider', '+919655005689', '+915554646464', NULL, 'Heart Attack,Drowned', 11.4814196000, 77.8837098000, NULL, 'VERIFIED'),
(00058, 'sanjit', '+919865999226', 21, 'Male', 'O+', 'udumalpet', 'Normal person', '+919345880768', NULL, NULL, NULL, 10.6027774000, 77.2607455000, NULL, 'VERIFIED'),
(00059, 'VISHAL E', '+919629976811', 20, 'Male', 'B-', 'Xyz', 'Normal people', '+919629976811', NULL, NULL, NULL, 12.9358143000, 79.1476307000, NULL, 'VERIFIED'),
(00061, 'fyfycy', '+919655005688', 838, 'Male', 'A+', 'cfdd', 'First Aider', '+912838686868', NULL, NULL, NULL, NULL, NULL, NULL, 'VERIFIED');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `Users`
--
ALTER TABLE `Users`
  ADD PRIMARY KEY (`UserId`),
  ADD UNIQUE KEY `PhoneNumber` (`PhoneNumber`),
  ADD UNIQUE KEY `UserName` (`UserName`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `Users`
--
ALTER TABLE `Users`
  MODIFY `UserId` int(5) UNSIGNED ZEROFILL NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=62;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
